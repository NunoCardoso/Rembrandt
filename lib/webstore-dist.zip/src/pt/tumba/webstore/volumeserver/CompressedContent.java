package pt.tumba.webstore.volumeserver;



/**
 * Represents a compressed content, and its compression mode.
 *  
 * @author Andre Santos, XLDB
 */
public class CompressedContent extends ServerReply {

	// compression mode
    String compress_mode;
    
    // compressed content
    byte[] data;

	/**
 	 * Creates a new instance from a string and an array of bytes.
 	 * 
 	 * @param compress_mode Compression mode.
 	 * @param data Compressed data.
 	 */
    public CompressedContent(String compress_mode, byte[] data) {
        this.compress_mode = compress_mode;
        this.data = data;
    }
    
    /**
     * Returns the compression mode.
     * 
     * @return A String representing the compression mode.
     */
    public String getCompressionMode() {
    	return compress_mode;
    }
    
    /**
     * Returns the compressed content.
     * 
     * @return A stream of bytes.
     */
    public byte[] getCompressedContent() {
    	return data;
    }
}
