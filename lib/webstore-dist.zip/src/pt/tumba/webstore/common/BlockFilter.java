package pt.tumba.webstore.common;

import java.io.File;
import java.io.FileFilter;

/**
 * File filter to catch files starting with a specified path.
 */
public class BlockFilter implements FileFilter {

	String starting_with;

	public BlockFilter(String starting_with) {
		this.starting_with = starting_with;
	}
    
	public boolean accept(File pathname) {
		String path = pathname.getName();
		return path.startsWith(starting_with);
	}
}