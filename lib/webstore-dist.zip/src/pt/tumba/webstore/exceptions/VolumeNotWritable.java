package pt.tumba.webstore.exceptions;

import pt.tumba.webstore.Volume;



/**
 * Thrown when the user attempts to store a content in a volume that is full, and therefore, not available for storing. 
 * 
 * @author Andre Santos, XLDB
 */
public class VolumeNotWritable extends Exception {

    public VolumeNotWritable(Volume vol) {
        super("The volume '" + vol + "' is complete.");
    }
}
