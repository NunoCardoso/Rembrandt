package pt.tumba.webstore.volumeserver;

import java.io.Serializable;

public abstract class ServerReply implements Serializable {

}
