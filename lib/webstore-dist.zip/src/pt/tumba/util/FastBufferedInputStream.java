package pt.tumba.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;

/** Lightweight, unsynchronised, aligned buffering class.
 *
 * <P>This class provides buffering for input streams, but it does so with 
 * purposes and an internal logic that are radically different from the ones
 * adopted in {@link java.io.BufferedInputStream}.
 * 
 * <P>There is no support for marking. All methods are unsychronised. Moreover,
 * it is guaranteed that <em>all reads performed by this class will be
 * multiples of the given buffer size</em>.  If, for instance, you use the
 * default buffer size, reads will be performed on the underlying input stream
 * in multiples of 16384 bytes. This is very important on operating systems
 * that optimise disk reads on disk block boundaries.
 * 
 * <P>As an additional feature, this class implements the {@link
 * RepositionableStream} interface.  An instance of this class will try to cast
 * the underlying byte stream to a {@link RepositionableStream} and to fetch by
 * reflection the {@link java.nio.channels.FileChannel} underlying the given
 * output stream, in this order.  If either reference can be successfully
 * fetched, you can use {@link #position(long)} to reposition the stream.
 * Note that even in this case, it is still guaranteed that all reads will
 * be performed on buffer boundaries, that is, as if the stream was divided
 * in blocks of the size of the buffer.
 */

public class FastBufferedInputStream extends InputStream {

	/** The default size of the internal buffer in bytes (16Ki). */
	public final static int DEFAULT_BUFFER_SIZE = 16 * 1024;

	/** The number of buffer bytes available starting from {@link #pos}. */
	protected int avail;

	/** The internal buffer. */
	protected byte buffer[];

	/** The cached file channel underlying {@link #is}, if any. */
	private FileChannel fileChannel;

	/** The underlying input stream. */
	protected InputStream is;

	/** The current position in the buffer. */
	protected int pos;

	/** Creates a new fast buffered input stream by wrapping a given input stream with a buffer of {@link #DEFAULT_BUFFER_SIZE} bytes. 
	 *
	 * @param is an input stream to wrap.
	 */
	public FastBufferedInputStream( final InputStream is ) {
		this( is, DEFAULT_BUFFER_SIZE );
	}

	/** Creates a new fast buffered input stream by wrapping a given input stream with a given buffer size. 
	 *
	 * @param is an input stream to wrap.
	 * @param bufSize the size in bytes of the internal buffer.
	 */

	public FastBufferedInputStream( final InputStream is, final int bufSize ) {
		this.is = is;
		boolean error = false;
		buffer = new byte[ bufSize ];
			try {
				fileChannel = (FileChannel)( is.getClass().getMethod( "getChannel", new Class[] {} ) ).invoke( is, new Object[] {} );
			}
			catch( IllegalAccessException e ) {error = true;}
			catch( IllegalArgumentException e ) {error = true;}
			catch( NoSuchMethodException e ) {error = true;}
			catch( java.lang.reflect.InvocationTargetException e ) {error = true;}
			catch( ClassCastException e ) {error = true;}
	}


	public int available() throws IOException {
		return is.available() + avail;
	}

	public void close() throws IOException {
		if ( is == null ) return;
		if ( is != System.in ) is.close();
		is = null;
		buffer = null;
	}

	public long position() throws IOException {
		if ( fileChannel != null ) return fileChannel.position() - avail;
		else throw new UnsupportedOperationException( "position() can only be called if the underlying byte stream implements the RepositionableStream interface or if the getChannel() method of the underlying byte stream exists and returns a FileChannel" );
	}

	public void position( long newPosition ) throws IOException {

		final long position = position();

		if ( newPosition <= position + avail && newPosition >= position - pos ) {
			pos += newPosition - position;
			avail -= newPosition - position;
			return;
		}

		final int residual = (int)( newPosition % buffer.length );
		
		if ( fileChannel != null ) fileChannel.position( newPosition - residual );
		else throw new UnsupportedOperationException( "position() can only be called if the underlying byte stream implements the RepositionableStream interface or if the getChannel() method of the underlying byte stream exists and returns a FileChannel" );

		avail = Math.max( 0, is.read( buffer ) );
		pos = Math.min( residual, avail );
		avail -= pos;
	}

	public int read() throws IOException {
		if ( avail == 0 ) {
			avail = is.read( buffer );
			if ( avail <= 0 ) {
				avail = 0;
				return -1;
			}
			pos = 0;
		}
		avail--;
		return buffer[ pos++ ] & 0xFF;
	}


	public int read( final byte b[], int offset2, int length2 ) throws IOException {
		int offset = offset2;
		int length = length2;
		if ( length <= avail ) {
			System.arraycopy( buffer, pos, b, offset, length );
			pos += length;
			avail -= length;
			return length;
		}
	
		final int head = avail;
		System.arraycopy( buffer, pos, b, offset, head );
		offset += head;
		length -= head;
		avail = 0;

		final int residual = length % buffer.length;
		int result;

		if ( ( result = is.read( b, offset, length - residual ) ) < length - residual ) 
			return result < 0 
				? ( head != 0 ? head : -1 ) 
				: result + head;

		avail = is.read( buffer );
		if ( avail < 0 ) {
			avail = 0;
			return result + head > 0 ? result + head : -1;
		}
		pos = Math.min( avail, residual );
		System.arraycopy( buffer, 0, b, offset + length - residual, pos );
		avail -= pos;
		return result + head + pos;
	}


	public long skip( long n2 ) throws IOException {
		long n = n2;
		if ( n <= avail ) {
			final int m = (int)n;
			pos += m;
			avail -= m;
			return n;
		}

		final int head = avail;
		n -= head;
		avail = 0;

		final int residual = (int)( n % buffer.length );
		long result;
		if ( ( result = is.skip( n - residual ) ) < n - residual ) {
			avail = 0;
			return result + head;
		}

		avail = Math.max( is.read( buffer ), 0 );
		pos = Math.min( residual, avail );
		avail -= pos;
		return result + head + pos;
	}

}
	

// Local Variables:
// mode: jde
// tab-width: 4
// End:
