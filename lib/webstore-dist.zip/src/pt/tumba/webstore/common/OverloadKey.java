package pt.tumba.webstore.common;

import pt.tumba.webstore.Key;



public class OverloadKey extends Key {

	//	overload number
	 private int overload;
    
	/**
	 * @param volume_id Volume id.
	 * @param signature Signature.
	 * @param first Is it the first?
	 * @param overload Overload number.
	 */
	public OverloadKey(String volume_id, long signature, boolean first, int overload) {
		super(volume_id,signature,first);
		this.overload = overload;
	}

	/**
	  * Returns the overload number.
	  *
	  * @return An integer.
	  */
	int overloadNumber() {
		return overload;
	}
	
	/**
	  * Returns a 16-character string with the hexadeximal key's signature representation. 
	  *
	  * @return A 16-character string; if the key is related with an overload, it returns a larger string, in the form '****************.overload_number'.
	  */
	protected String hexSignature() {
		return super.hexSignature() + "." + overload;
	}

	
	/**
	 * Returns an external representation of the key.
	 * 
	 * @return Something in the form: <i>key@volume</i>{<i>%</i>}.
	 */
	public String toExternalFormat() {
		return signature + "." + overload + "@" + volume_id + (first ? "%" : "");
	}
    
}
