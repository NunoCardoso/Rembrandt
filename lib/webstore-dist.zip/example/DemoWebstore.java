import java.io.File;

import pt.tumba.webstore.*;


public class DemoWebstore {

    public static void main(String[] args) {

        try {
	    System.out.println("usage: java DemoWebstore 			WEBSTORE_CONFIG_FILE");
            WebStore ws = new WebStore(new File(args[0]));


            String s1 = "Hello!";
            String s2 = "Goodbye!";

            Content original1 = new Content(s1.getBytes());
            Content original2 = new Content(s2.getBytes());

            ws.setDefaultCompressMode(WebStore.ZLIB);

            // store a content using the regular option
            Key key1 = ws.store(original1);

            Volume[] volumes = ws.getVolumes(WebStore.WRITABLE);

            // store a content in a specified volume using the force new option
            // [assuming that there is at least one writable volume] 
			ws.setDefaultDuplicatesPolicy(Webstore.FORCE_NEW_POLICY);
            Key key2 = ws.store(original2,volumes[0]);

            // retrieve the same content with the given keys

            Content content1 = ws.retrieve(key1);
            Content content2 = ws.retrieve(key2);

            // content1.equals(original1) and content2.equals(original2) should return true
            // delete the contents with the given keys

            ws.delete(key1);
            ws.delete(key2);

        }
        catch(Exception ex) {
            // different exceptions can occour here
            System.out.println(ex.getMessage());
        }
	System.out.println("DemoWebstore ran successfully.");
    }

}
