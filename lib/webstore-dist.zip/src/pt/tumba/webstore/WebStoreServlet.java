package pt.tumba.webstore;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pt.tumba.webstore.exceptions.ContentNotFound;
import pt.tumba.webstore.exceptions.InvalidConfigFile;
import pt.tumba.webstore.exceptions.InvalidKey;

/**
 * Servlet for retrieving WebStore contents.
 * - It initializes with the webstore configuration defined by the configuration
 * file located in the servlet init parameter 'WEBSTORE_CONFIG_FILE'.
 * - It expects the parameter 'key', which should contain a WebStore key in the
 * external format (string). 
 */
public class WebStoreServlet extends HttpServlet {

    private WebStore webstore;
    
    public void init() {
        String CONFIG_FILE = getInitParameter("WEBSTORE_CONFIG_FILE");
        try {
            webstore = new WebStore(new File(CONFIG_FILE));
        }
        catch(InvalidConfigFile ex) {
            ex.printStackTrace();
        }
    }
    
    public synchronized void doPost(HttpServletRequest request, HttpServletResponse res)
    throws IOException, ServletException {
        doGet(request,res);
    }
    
    public synchronized void doGet(HttpServletRequest request, HttpServletResponse res) 
    throws IOException, ServletException {	

        PrintWriter out = res.getWriter();
        res.setContentType("text/html");
        
        String key = request.getParameter("key");
        out.println(key);
        
        Key internalkey = null;
        if(key != null)
            internalkey = Key.toKey(key);
        
        if(key == null || internalkey == null) {
            out.println("ERROR: param 'key' not defined, or contains an invalid key.");
        }
        else {
            Content content = null;
            try {
                content = webstore.retrieve(internalkey);
            }
            catch(InvalidKey ex0) {
                out.println("ERROR: the supplied key '" + key + "' is invalid.");
            }
            catch(ContentNotFound ex1) {
                out.println("ERROR: content with key '" + key + "' was not found.");
            }
            catch(Exception ex2) {
                ex2.printStackTrace(out);
            }
        
            if(content != null) {
                String data = new String(content.getData());
                out.print(data);
            }
        }
        
        out.close();
    }
}
    
