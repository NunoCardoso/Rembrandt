package pt.tumba.webstore;

import jargs.gnu.CmdLineParser;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.RandomAccessFile;

import pt.tumba.webstore.common.ConfigParser;
import pt.tumba.webstore.common.Header;
import pt.tumba.webstore.exceptions.InvalidConfigFile;
import pt.tumba.webstore.volumeserver.FileAccess;



/**
 * This is a class that provides methods for configuring and monitoring webstore volumes. 
 * 
 * @author Andre Santos, XLDB
 */
public class PosixFSVolume {

	private FileAccess fileaccess = FileAccess.Instance();
	
	private boolean refcounts = true;

	private File volume_dir;
	
	private Volume volume;
	
	/**
	 * Creates a new Posix Filesystem WebStore volume.
	 * 
	 * @param cfg_file Webstore configuration file.
	 * @param volume_dir Volume root directory.
	 */
	public PosixFSVolume(File cfg_file, String volume_dir) {
		ConfigParser cfgparser = new ConfigParser();
				
		try {
			cfgparser.parse(cfg_file);
		}
		catch(InvalidConfigFile ex1) {
			System.err.println(ex1.getMessage());
			System.exit(1);
		}
		
		if(volume_dir != null) {
			String vol = volume_dir.substring(volume_dir.lastIndexOf(File.separatorChar) + 1);
			Volume[] vols = cfgparser.getVolumes();
			boolean found = false;
			for(int i = 0; !found && i < vols.length; i++)
				if(vols[i].vol_id.equals(vol)) {
					this.volume_dir = new File(volume_dir);
					this.volume = vols[i];
					found = true;	
				}
		
			if(!found) {
				System.err.println("No matching volume for \"" + vol + "\" in configuration file.");
				System.exit(1);
			}
		}
		else {
			this.volume_dir = null;
			this.volume = null;
		}
	}
	
	/**
	 * Count the number of contents stored in a volume.
	 * 
	 * @return The sum of the reference counters values.
	 */
	public int countContents() {
		return count_refcounts(volume_dir);
	}
	
	

 	
 	/**
 	 * Counts the number of files on the volume.
 	 * 
 	 * @return Number of files on the directory tree.
 	 */
 	public int countFiles() {
 		return count_files(volume.depth,"");
 	}
 

    /**
     * Counts the number of file overloads in a volume.
     * 
     * @return The number of files which resulted from file overloads.
     */
    public int countFileOverloads() {
    	return count_overloads(volume.depth,volume_dir.getAbsolutePath() + File.separatorChar);
    }

    /**
     * Deletes all the files on the volume.
     */
    public void erase() {
    	delete_files(volume.depth,volume_dir.getAbsolutePath() + File.pathSeparatorChar);
    }
    
	/**
	 * Creates the volume directory tree according to the configuration file.
	 */
	public void initialize() throws Exception {
		create_dirs(volume.depth,volume_dir.getAbsolutePath() + File.pathSeparatorChar);
	}
		
    /**
     * Main.
     */
    public static void main(String args[]) {
		
		String WEBSTORE_HOME = System.getProperty("WEBSTORE_HOME");
		if(WEBSTORE_HOME == null) {
			System.err.println("Property WEBSTORE_HOME not defined. Quiting.");
			System.exit(1);
		}
		if(WEBSTORE_HOME.charAt(WEBSTORE_HOME.length() - 1) == File.pathSeparatorChar)
			WEBSTORE_HOME.substring(0,WEBSTORE_HOME.length() - 1);

		String WEBSTORE_DATA = System.getProperty("WEBSTORE_DATA");
		if(WEBSTORE_DATA == null) {
			System.err.println("Property WEBSTORE_DATA not defined. Quiting.");
			System.exit(1);
		}
		if(WEBSTORE_DATA.charAt(WEBSTORE_DATA.length() - 1) == File.pathSeparatorChar)
			WEBSTORE_DATA.substring(0,WEBSTORE_DATA.length() - 1);
			
		String CONFIG_FILE = System.getProperty("CONFIG_FILE");
		if(CONFIG_FILE == null) {
			System.err.println("Property CONFIG_FILE not defined. Quiting.");
			System.exit(1);
		}
		
		CmdLineParser parser = new CmdLineParser();
		CmdLineParser.Option f = parser.addStringOption('f', "count-files");
		CmdLineParser.Option c = parser.addStringOption('c', "count-contents");
		CmdLineParser.Option o = parser.addStringOption('o', "count-overloads");
		CmdLineParser.Option m = parser.addStringOption('m', "make-volume");
		CmdLineParser.Option e = parser.addStringOption('e', "erase-volume");
		CmdLineParser.Option r = parser.addStringOption('r', "retrieve");
		CmdLineParser.Option s = parser.addStringOption('s', "store");
		CmdLineParser.Option d = parser.addStringOption('d', "delete");
		
		try {
			parser.parse(args);
		}
		catch(CmdLineParser.OptionException ex) {
			System.err.println(ex.getMessage());
			System.exit(2);
		}

		PosixFSVolume pfsv = new PosixFSVolume(new File(CONFIG_FILE),null);	
		
		String val = null;
		
		// Count files
		val = (String) parser.getOptionValue(f);
		if(val != null) {
			pfsv.refcounts = false;
			System.out.println("Counting files...");
			pfsv.refcounts(WEBSTORE_DATA + File.separatorChar + val);
		}
		
		// Count contents
		val = (String) parser.getOptionValue(c);
		if(val != null) {
			System.out.println("Counting contents...");
			pfsv.refcounts(WEBSTORE_DATA + File.separatorChar + val);
		}
		
		// Count file overloads
		val = (String) parser.getOptionValue(o);
		if(val != null) {
			System.out.println("Counting file overloads...");
			pfsv.overloads(WEBSTORE_DATA + File.separatorChar + val);
		}
		
		// Make volume
		val = (String) parser.getOptionValue(m);
		if(val != null) {
			System.out.println("Creating storage structure...");
			pfsv.make_vol(WEBSTORE_DATA + File.separatorChar + val,CONFIG_FILE);
		}
		
		// Erase volume
		val = (String) parser.getOptionValue(e);
		if(val != null) {
			System.out.println("Erasing all the contents...");
			pfsv.erase_vol(WEBSTORE_DATA + File.separatorChar + val);
		}
		
		// Store content
		val = (String) parser.getOptionValue(s);
		if(val != null) {
			if(args.length != 3) {
				System.err.println("Wrong number of arguments.");
				System.exit(1);
			}
			pfsv = new PosixFSVolume(new File(CONFIG_FILE),WEBSTORE_DATA + File.separatorChar + args[1]);	
			try {
				WebStore ws = new WebStore(new File(CONFIG_FILE));
				FileInputStream fis = new FileInputStream(args[2]);
				Content content = new Content(fis);
				fis.close();
				Key key = ws.store(content,pfsv.volume);
				System.out.println(key);
			}
			catch(Exception ex) {
				System.err.println(ex.getMessage());
			}
		}
		
		// Retrieve content
		val = (String) parser.getOptionValue(r);
		if(val != null) {
			try {
				WebStore ws = new WebStore(new File(CONFIG_FILE));
				Key key = Key.toKey(val);
				if(key == null) {
					System.err.println("The given key is invalid.");
					System.exit(1);
				}
				Content cont = ws.retrieve(key);
				System.out.print(new String(cont.getData()));
			}
			catch(Exception ex) {
				System.err.println(ex.getMessage());
			}
		}

		// Delete content
		val = (String) parser.getOptionValue(d);
		if(val != null) {
			try {
				WebStore ws = new WebStore(new File(CONFIG_FILE));
				Key key = Key.toKey(args[1]);
				if(key == null) {
					System.err.println("The given key is invalid.");
					System.exit(1);
				}
				ws.delete(key);
			}
			catch(Exception ex) {
				System.err.println(ex.getMessage());
			}
		}
    } // Main
    
    
    
	private static void create_dirs(int depth,String path) throws Exception {
		if(depth == 0)
			return;
		File f = null;
		int i = 0x0;
		String s = null;
		while(i <= 0xFF) {
			s = Integer.toHexString(i);
			if(s.length() != 2)
				s = "0" + s;        
			f = new File(path + s);
			try {
				f.mkdir();
			}
			catch(Exception ex) {
				throw ex;
			}
			create_dirs(depth - 1,path + s + File.separatorChar);
			i++;
		}        
	}
			
    
    private void refcounts(String filename) {		
		File dir = new File(filename);
	
		if(!dir.exists()) {
			System.err.println("The directory \"" + filename + "\" doesn't exist.");
			System.exit(2);
		}
		else
			if(!dir.isDirectory()) {
				System.err.println("\"" + filename + "\" is not a directory.");
				System.exit(2); 
			}
	
		String absolutepath = dir.getAbsolutePath();
		System.out.println("volume root: " + absolutepath);
			
		absolutepath += "/ff";
		int depth = 0;
		for(; (new File(absolutepath)).exists(); depth++) 
			absolutepath += "/ff";
		
		
		
		System.out.println("Total: " + count_files(depth,filename + File.separatorChar));	
    }

	private int count_files(int depth,String path) {
    	
		if(depth == 0) {
			File dir = new File(path);
			return refcounts ? count_refcounts(dir) : dir.listFiles().length;
		}

		int i = 0x0;

		String s = null;
		int count = 0;

		while(i <= 0xff) {
			s = Integer.toHexString(i);
			if(s.length() != 2)
				s = "0" + s;

			count += count_files(depth-1,path + s + File.separatorChar);
			i++;
		}
		return count;
	}
    
	private int count_refcounts(File dir) {
		File [] files = dir.listFiles();
		Header h = null;
		int ret = 0;
        
		try {
			for(int i = 0; i < files.length; i++) {
				RandomAccessFile ras = fileaccess.getFileDescriptor(files[i],FileAccess.READ);
				h = fileaccess.getHeader(ras);
				fileaccess.close(ras);
				ret += h.refCounter();
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}

		return ret;
	}
	
	private void overloads(String filename) {		
		File dir = new File(filename);
	
		if(!dir.exists()) {
			System.err.println("The directory \"" + filename + "\" doesn't exist.");
			System.exit(2);
		}
		else
			if(!dir.isDirectory()) {
				System.err.println("\"" + filename + "\" is not a directory.");
				System.exit(2); 
			}

		String absolutepath = dir.getAbsolutePath();
		System.out.println("volume root: " + absolutepath);
		
		absolutepath += "/ff";
		int depth = 0;
		for(; (new File(absolutepath)).exists(); depth++) 
			absolutepath += "/ff";
				
		System.out.println("Total: " + count_overloads(depth,filename + File.separatorChar));	
	}
    
	private int count_overloads(int depth,String path) {
		if(depth == 0) {
			File dir = new File(path);
			File[] files = dir.listFiles(new CollisionFilter());
			for(int i = 0; i < files.length; i++)
				System.out.println(files[i]);
			return files.length;
		}

		int i = 0x0;

		String s = null;
		int count = 0;

		while(i <= 0xff) {
			s = Integer.toHexString(i);
			if(s.length() != 2)
				s = "0" + s;

			count += count_overloads(depth-1,path + s + File.separatorChar);
			i++;
		}
		return count;
	}
	
    private void erase_vol(String filename) {
		File dir = new File(filename);
	
		if(!dir.exists()) {
			System.err.println("The directory \"" + filename + "\" doesn't exist.");
			System.exit(2);
		}
		else
			if(!dir.isDirectory()) {
				System.err.println("\"" + filename + "\" is not a directory.");
				System.exit(2); 
			}
	
		String absolutepath = dir.getAbsolutePath();
		System.out.println("volume root: " + absolutepath);
			
		absolutepath += "/ff";
		int depth = 0;
		for(; (new File(absolutepath)).exists(); depth++) 
				absolutepath += "/ff";
		
		delete_files(depth,filename + File.separatorChar);
    }
    
	private void delete_files(int depth,String path) {
		if(depth == 0) {
			File[] files  = (new File(path)).listFiles();
			for(int i = 0; i < files.length; i++)
				if(!files[i].delete())
					System.out.println("It wasn't possible to delete the file: " + files[i]);
			return;
		}

		int i = 0x0;

		String s = null;

		while(i <= 0xff) {
			s = Integer.toHexString(i);
			if(s.length() != 2)
				s = "0" + s;

			delete_files(depth-1,path + s + File.separatorChar);
			i++;
		}
	}

    private void make_vol(String root_dir, String cfg_file) {		
				
		File file = new File(cfg_file);	 
			
		if(!file.exists() || file.isDirectory()) {
			System.err.println("\"" + file + "\" - Configuration file not found.");
			System.exit(2);
		}
				
		ConfigParser cfgparser = new ConfigParser();
				
		try {
			cfgparser.parse(file);
		}
		catch(InvalidConfigFile ex1) {
			System.err.println(ex1.getMessage());
			System.exit(1);
		}
			
		boolean match = false;
		int i = 0;
		String vol = root_dir.substring(root_dir.lastIndexOf(File.separatorChar) + 1);
		Volume[] vols = cfgparser.getVolumes();
		for(; i < vols.length && !match; i++)
			if(vols[i].toString().equals(vol)) {
				match = true;
				i--;
			}
			
		if(!match) {
			System.err.println("No matching volume for \"" + vol + "\" in configuration file.");
			System.exit(1);
		}
				
		File root = new File(root_dir);
		
		if(!root.exists()) {
			if(!root.mkdir()) {
				System.err.println("It was not possible to create the root directory \"" + root.getAbsolutePath() + "\".");
				System.exit(1);
			}
		}
		else {
			if(!root.isDirectory()) {
				System.out.println("\"" + root_dir + "\" is a file.");
				System.exit(1);
			}
		}
				
	
		System.out.println("Creating directory tree...");
		System.out.println("volume depth: " + vols[i].getDepth());			
	
		long time = System.currentTimeMillis();
		try {
			create_dirs(vols[i].getDepth(),root.getAbsolutePath() + File.separatorChar);
		}
		catch(Exception ex2) {
			System.err.println(ex2.getMessage());
			System.exit(1);
		} 
		System.out.println("time: " + ((System.currentTimeMillis() - time) / 1000) + " seconds.");    
    }
    
    
    
    
		/**
		* File filter to catch files starting with a specified path.
		*/
	   private class CollisionFilter implements FileFilter {
        
		   public boolean accept(File pathname) {
			   String path = pathname.getName();
			   return path.indexOf('.') != -1;
		   }
	   }
}


