/**
 * Header.java
 */
 package pt.tumba.webstore.common;

import java.io.Serializable;


/**
 * Represents a WebStore's file header.
 * 
 * @author Andre Santos, XLDB
 */
public class Header implements Serializable {
	
	// field "x-webstore-version"
    String version;
    
    // field "x-webstore-compression"
    String compress_mode;
    
    // field "x-webstore-contentsize"
    long content_size;
    
    // field "x-webstore-refcount"
    int refcount;

	/**
 	 * Creates a new instance given the version, compression mode, content size and initial <i>refcount</i> value.
 	 *
 	 * @param version Webstore version.
 	 * @param compress_mode Compression mode.
 	 * @param content_size Content size.
 	 * @param refcount Refcount initial value.
 	*/
    public Header(String version,
           String compress_mode,
           long content_size,
           int refcount) {
        this.version = version;
        this.compress_mode = compress_mode;
        this.content_size = content_size;
        this.refcount = refcount;
    }

	/**
	 * Returns the WebStore version that stored the content.
	 * 
	 * @return A String that represents the WebStore version.
	 */
    public String version() {
        return version;
    }

	/**
	 * Returns the compression mode.
	 * 
	 * @return A string representation of the compression mode.
	 */
    public String compressMode() {
        return compress_mode;
    }

	/**
	 * Returns the content size.
	 * 
	 * @return A long containing the content's size.
	 */
    public long contentSize() {
        return content_size;
    }

	/**
	 * Returns the <i>refcount</i> value.
	 * 
	 * @return An int containing the <i>refcount</i> value.
	 */
    public int refCounter() {
        return refcount;
    }
    
    /**
     * Returns a string representation of a block header.
     */
    public String toString() {
    	return "<" + version + "," + compress_mode + "," + content_size +
    		"," + refcount + ">";
    }
}
