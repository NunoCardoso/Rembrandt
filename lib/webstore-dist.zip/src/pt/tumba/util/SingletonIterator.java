/*
 * Created on 9/Dez/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package pt.tumba.util;

/**
 * Iterators over a single object 
 *
 * @author Jez Higgins, jez@jezuk.co.uk
 * @version $Id: SingletonIterator.java,v 1.1 2003/12/09 17:45:28 bmartins Exp $
 */
public class SingletonIterator implements java.util.Iterator
{
  public SingletonIterator(Object object)
  {
    object_ = object;
  } // SingletonIterator

  public boolean hasNext()
  {
    return (object_ != null);
  } // hasNext

  public Object next()
  {
    Object o = object_;
    object_ = null;
    return o;
  } // next

  public void remove()
  {
    throw new UnsupportedOperationException("uk.co.jezuk.mango.SingletonIterator does not support the remove method");
  } // remove

  //////////////////////
  private Object object_;
} // SingletonIterator
