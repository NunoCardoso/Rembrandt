package pt.tumba.webstore.exceptions;

import java.io.File;

import pt.tumba.webstore.Key;



/**
 * Thrown when a content wasn't found during  a <i>retrieve</i> or <i>delete</i> operation.
 * 
 * @author Andre Santos, XLDB
 */
public class ContentNotFound extends Exception {

    public ContentNotFound(Key key) {
        super("There is no content stored corresponding to the given key [" + key + "].");
    }
    
	public ContentNotFound(Key key, File file) {
		super("There is no content stored corresponding to the given key [" + key + "]; file '" + file + "'.");
	}
}
