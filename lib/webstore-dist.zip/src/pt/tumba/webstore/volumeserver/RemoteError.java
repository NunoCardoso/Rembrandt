package pt.tumba.webstore.volumeserver;


public class RemoteError extends ServerReply {

}

