package pt.tumba.webstore.common;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetSocketAddress;
import java.util.List;
import java.util.Vector;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import pt.tumba.webstore.Volume;
import pt.tumba.webstore.exceptions.InvalidConfigFile;


/**
 * XML SAX-parser for WebStore's configuration files.
 *  
 * @author Andre Santos, XLDB
 */

public class ConfigParser extends DefaultHandler {

    // name
    public String name;

    // volumes
    private Volume[] volumes;

    private List vols_vec;
    
	private static Writer out;
	
	/**
	 * Default server port.
	 */
	public static final int DEFAULT_PORT = 4444;
	
	/**
	 * Default maximum number of runing threads in the server. 
	 */
	public static final int DEFAULT_MAX_THREADS = 40;
	
	/**
	 * Default log file name.
	 */
	public static final String DEFAULT_LOGFILE = "volume-server";
	
    /**
     * Creates an instance of ConfigParser.
     */
    public ConfigParser() {
    	name = null;
    	volumes = null;
    	vols_vec = new Vector();
    }
    
    /**
     * Returns the parsed Volume's instances.
     * 
     * @return An array of Volume.
     */
    public Volume[] getVolumes() {
    	return volumes;
    }
    
    /**
     * Parses a XML WebStore configuration file.
     * 
     * @param file Configuration file.
     * 
     * @throws InvalidConfigFile When the given file is not a valid configuration file for WebStore.
     */
    public void parse(File file) throws InvalidConfigFile {
       
        SAXParserFactory factory = SAXParserFactory.newInstance();
		
        try {
            out = new OutputStreamWriter(System.out,"UTF-8");
            SAXParser saxParser = factory.newSAXParser();
            saxParser.parse(file,this);
        }
        catch(Exception ex) {        	
            throw new InvalidConfigFile(file.toString(),"");
        }
    
    }

    public  void startDocument() throws SAXException {
    }
    
    public void endDocument() throws SAXException {
        try {
            out.flush();
        }
        catch (IOException e) {
            throw new SAXException("I/O error", e);
        }

        volumes = new Volume[vols_vec.size()];
        for(int i = 0; i < volumes.length; i++)
            volumes[i] = (Volume) vols_vec.get(i);
    }
    
    public void startElement(String namespaceURI, String sName, String qName, Attributes attrs)
    	throws SAXException {

        if(qName.equals("webstore")) {
            for(int i = 0; i < attrs.getLength(); i++) {                
                if(attrs.getQName(i).equals("name"))
                    name = attrs.getValue(i);
            }

            if(name == null)
                throw new SAXException("Name not defined.");
        }
        else if(qName.equals("volume")) {
       
            String id = null, mode = null, depth = null, server = null, port = null, logfile = null, maxthreads = null;
            
            for(int i = 0; i < attrs.getLength(); i++) {
                if(attrs.getQName(i).equals("id"))
                    id = attrs.getValue(i);
                else
                    if(attrs.getQName(i).equals("mode"))
                        mode = attrs.getValue(i);
					else
						if(attrs.getQName(i).equals("tree-depth"))
							depth = attrs.getValue(i);
						else
							if(attrs.getQName(i).equals("server"))
								server = attrs.getValue(i);
							else
								if(attrs.getQName(i).equals("port"))
									port = attrs.getValue(i);
									else
										if(attrs.getQName(i).equals("logfile"))
											logfile = attrs.getValue(i);
										else
											if(attrs.getQName(i).equals("max-threads"))
												maxthreads = attrs.getValue(i);
            }

			if(id == null || mode == null || depth == null || server == null)
				throw new SAXException("The attributes 'id', 'mode', 'tree-depth', 'server' are compolsory for every 'volume' element.");		
		
			int tree_depth = -1;
			try {
				tree_depth = Integer.parseInt(depth);
			}
			catch(NumberFormatException ex) {
				throw new SAXException("The attribute 'tree-depth' doesn't contain a valid integer.");
			}
			
			if(!mode.equals("full") && !mode.equals("writable"))
				throw new SAXException("The valid values for mode are 'full' and 'writable'."); 
			
			boolean writable = mode.equals("writable");
			
			int port_number = -1;
			
			if(port == null )
				port_number = DEFAULT_PORT;
			else {
				try {
					port_number = Integer.parseInt(port);
				}
				catch(NumberFormatException ex) {
					port_number = DEFAULT_PORT;
				}
			}
	
			int max_threads = -1;
			if(maxthreads == null)
				max_threads = DEFAULT_MAX_THREADS;
			else {
				try {
					max_threads = Integer.parseInt(maxthreads);
				}
				catch(NumberFormatException ex) {
					max_threads = DEFAULT_MAX_THREADS;
				}
			}
			
			InetSocketAddress isa = null; 
			try {
				isa = new InetSocketAddress(server,port_number);
			}
			catch(Exception ex) {
				throw new SAXException(ex.getMessage());
			}
			
			File log = null;
			
			// only needed for VolumeServer
			String WEBSTORE_HOME = System.getProperty("WEBSTORE_HOME");
			if(WEBSTORE_HOME != null) {
				
				if(WEBSTORE_HOME.charAt(WEBSTORE_HOME.length() - 1) == File.separatorChar)
					WEBSTORE_HOME.substring(0,WEBSTORE_HOME.length() - 1);
				
				String logpath = null;
				if(logfile == null)
					logpath = WEBSTORE_HOME + File.separatorChar + "logs" + 
						File.separatorChar + DEFAULT_LOGFILE + "." + id + ".log";
				else
					logpath = WEBSTORE_HOME + File.separatorChar + "logs" +
						File.separatorChar + logfile;
						
				log = new File(logpath);
			}
			
        	vols_vec.add(new Volume(id,tree_depth,writable,isa,log,max_threads));
        }        
    }
    
    public void endElement(String namespaceURI,String sName,String qName)
    	throws SAXException {
    }

    public void notationDecl(String s1, String s2, String s3) throws SAXException {
        throw new SAXException(s1 + ":" + s2 + ":" + s3);
    }

    public void unparsedEntityDecl(String s1, String s2, String s3, String s4) throws SAXException {
        throw new SAXException(s1 + ":" + s2 + ":" + s3 + ":" + s4);
    }
}
