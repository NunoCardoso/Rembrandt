package pt.tumba.webstore.volumeserver;

import java.io.File;
import java.io.Serializable;



public abstract class Request implements Serializable {

	protected File file;
	
	public Request(File file) {
		this.file = file;
	}
	
	public String toString() {
		return file.getPath();
	}
}