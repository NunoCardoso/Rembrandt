package pt.tumba.util;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.SecureRandom;

public class UUIDGenerator {

	private SecureRandom seeder;
	private String value;

	public UUIDGenerator() throws UnknownHostException {
			StringBuffer stringbuffer = new StringBuffer();
			seeder = new SecureRandom();
			InetAddress inetaddress = InetAddress.getLocalHost();
			byte abyte0[] = inetaddress.getAddress();
			String s = hexFormat(getInt(abyte0), 8);
			String s1 = hexFormat(System.identityHashCode(this), 8);
			stringbuffer.append(s.substring(0, 4));
			stringbuffer.append(s.substring(4));
			stringbuffer.append(s1.substring(0, 4));
			stringbuffer.append(s1.substring(4));
			value = stringbuffer.toString();
			seeder.nextInt();
	}
	
	private final String getVal(String s) {
		long l = System.currentTimeMillis();
		int i = (int) l & -1;
		int j = seeder.nextInt();
		return hexFormat(i, 8) + s + hexFormat(j, 8);
	}
	
	public final String getID() {
		return getVal(value);
	}
	
	private final int getInt(byte abyte0[]) {
		int i = 0;
		int j = 24;
		for (int k = 0; j >= 0; k++) {
			int l = abyte0[k] & 0xff;
			i += l << j;
			j -= 8;
		}
		return i;
	}
	
	private final String hexFormat(int i, int j) {
		String s = Integer.toHexString(i);
		return padHex(s, j) + s;
	}
	
	private final String padHex(String s, int i) {
		StringBuffer stringbuffer = new StringBuffer();
		if (s.length() < i) {
			for (int j = 0; j < i - s.length(); j++)
				stringbuffer.append("0");
		}
		return stringbuffer.toString();
	}
	
}