package pt.tumba.webstore.exceptions;


/**
 * Thrown when the given configuration file for the WebStore instance isn't valid.
 * 
 * @author Andre Santos, XLDB
 */
public class InvalidConfigFile extends Exception {

    public InvalidConfigFile(String filename, String msg) {
        super("The configuration file (" + filename + ") isn't a valid XML configuration file for WebStore.\n" + msg);
    }
 
}
