package pt.tumba.webstore.volumeserver;


public class OKNotFirst extends OK {

}
