/*
 * Hierarchy.java
 *
 */

package pt.tumba.util;

import java.util.*;


/**
 * This class allows groups of objects to be stored based on associated levels.
 * Levels are specified by integer values, and any given level can have an
 * arbitrary number of objects associated with it.  Methods are provided that
 * can find the highest and lowest occurrences of object instances, were "highness"
 * refers to the value of the integer representing the level. All of the public
 * methods of <CODE>Hierarchy</CODE> are synchronized.
 *
 */
public class Hierarchy {
	
	/** Error message constant about "no nulls allowed" */
	private static final String NO_NULLS_ERROR = "Null objects cannot be stored in a Hierarchy.";
	
	/** The <CODE>Map</CODE> of data, grouped by level in the <CODE>Hierarchy</CODE> */
	private Map levels = null;
	
	
	/**
	 * Creates a new instance of <CODE>Hierarchy</CODE>.
	 */
	public Hierarchy() {
		levels = new TreeMap();
	}
	
	/**
	 * Adds a new object at the supplied level of the <CODE>Hierarchy</CODE>.
	 *
	 * @param level the level of the <CODE>Hierarchy</CODE> at which to add
	 * the new object
	 * @param obj the object to be added
	 *
	 * @throws IllegalArgumentException if the supplied object is null
	 */
	public synchronized void add(int level, Object obj) {
		
		if( obj == null ) {
			throw new IllegalArgumentException( NO_NULLS_ERROR );
		}
		
		ensureStorageForLevel( level );
		Set setAtLevel = (Set)levels.get( new Integer( level ) );
		setAtLevel.add( obj );
	}
	
	/**
	 * Removes an object from the supplied level of the <CODE>Hierarchy</CODE>.
	 *
	 * @param level the level of the <CODE>Hierarchy</CODE> from which to remove
	 * the object
	 * @param obj the object to be removed
	 *
	 * @return true if the object was found and removed, false if it could not
	 * be found and therefore was not removed
	 *
	 * @throws IllegalArgumentException if the supplied object is null
	 */
	public synchronized boolean remove(int level, Object obj) {
		
		if( obj == null ) {
			throw new IllegalArgumentException( NO_NULLS_ERROR );
		}
		
		Set setAtLevel = getAll( level );
		if( setAtLevel != null ) {
			return setAtLevel.remove( obj );
			
		} else {
			return false;
		}
	}
	
	/**
	 * Returns the highest level at which the supplied object could be found
	 * in the <CODE>Hierarchy</CODE>, or <CODE>Integer.MIN_VALUE</CODE> if it
	 * could not be found at all.
	 *
	 * @param obj the object to look for
	 *
	 * @return the highest level at which the supplied object could be found
	 * in the <CODE>Hierarchy</CODE>, or <CODE>Integer.MIN_VALUE</CODE> if it
	 * could not be found at all
	 *
	 * @throws IllegalArgumentException if the supplied object is null
	 */
	public synchronized int findHighestOccurrence(Object obj) {
		Integer[] levelInts = (Integer[]) levels.keySet().toArray(new Integer[ levels.size() ]);
		
		int foundAt = Integer.MIN_VALUE;
		for( int i = levelInts.length-1; i >= 0; i-- ) {
			int levelInt = levelInts[i].intValue();
			if( contains( levelInt, obj ) ) {
				foundAt = levelInt;
				break;
			}
		}
		
		return foundAt;
	}
	
	/**
	 * Returns the lowest level at which the supplied object could be found
	 * in the <CODE>Hierarchy</CODE>, or <CODE>Integer.MAX_VALUE</CODE> if it
	 * could not be found at all.
	 *
	 * @param obj the object to look for
	 *
	 * @return the lowest level at which the supplied object could be found
	 * in the <CODE>Hierarchy</CODE>, or <CODE>Integer.MAX_VALUE</CODE> if it
	 * could not be found at all
	 *
	 * @throws IllegalArgumentException if the supplied object is null
	 */
	public synchronized int findLowestOccurrence(Object obj) {
		Integer[] levelInts = (Integer[]) levels.keySet().toArray(new Integer[ levels.size() ]);
		
		int foundAt = Integer.MAX_VALUE;
		for( int i = 0; i < levelInts.length; i++ ) {
			int levelInt = levelInts[i].intValue();
			if( contains( levelInt, obj ) ) {
				foundAt = levelInt;
				break;
			}
		}
		
		return foundAt;
	}
	
	/**
	 * Returns the <CODE>Set</CODE> containing all objects at the requested
	 * level of the <CODE>Hierarchy</CODE>, sorted in the order in which they
	 * were added.  If the result is null, then no such level has ever been used
	 * in the <CODE>Hierarchy</CODE> instance.
	 *
	 * @param level the level of the <CODE>Hierarchy</CODE> from which to return
	 * the <CODE>Set</CODE>
	 *
	 * @return the <CODE>Set</CODE> containing all objects at the requested
	 * level of the <CODE>Hierarchy</CODE>
	 */
	public synchronized SortedSet getAll(int level) {
		return (SortedSet)levels.get( new Integer( level ) );
	}
	
	/**
	 * Returns whether or not the <CODE>Hierarchy</CODE> contains the supplied
	 * object at the specified level.
	 *
	 * @param level the level at which to look for the object
	 * @param obj the object to look for
	 *
	 * @return whether or not the <CODE>Hierarchy</CODE> contains the supplied
	 * object at the specified level
	 *
	 * @throws IllegalArgumentException if the supplied object is null
	 */
	public synchronized boolean contains(int level, Object obj) {
		
		if( obj == null ) {
			throw new IllegalArgumentException( NO_NULLS_ERROR );
		}
		
		Set setAtLevel = getAll( level );
		if( setAtLevel != null ) {
			return setAtLevel.contains( obj );
			
		} else {
			return false;
		}
	}
	
	/**
	 * Returns whether or not the <CODE>Hierarchy</CODE> contains the supplied
	 * object at any level.
	 *
	 * @param obj the object to look for
	 *
	 * @return whether or not the <CODE>Hierarchy</CODE> contains the supplied
	 * object at any level
	 *
	 * @throws IllegalArgumentException if the supplied object is null
	 */
	public synchronized boolean contains(Object obj) {
		
		int foundAt = findLowestOccurrence( obj );
		boolean found = true;
		
		if( foundAt == Integer.MAX_VALUE ) {
			found = false;
		}
		
		return found;
	}
	
	/**
	 * Returns the number of levels that exist in the <CODE>Hierarchy</CODE>.
	 *
	 * @return the number of levels that exist in the <CODE>Hierarchy</CODE>
	 */
	public synchronized int levels() {
		return levels.size();
	}
	
	/**
	 * Ensures that there is storage available for objects at the supplied
	 * level of the <CODE>Hierarchy</CODE>.
	 *
	 * @param level the level in the <CODE>Hierarchy</CODE> to ensure that storage is
	 * available for
	 */
	private void ensureStorageForLevel(int level) {
		Integer i = new Integer( level );
		Object storage = levels.get( i );
		if( storage == null ) {
			storage = new LinkedHashSet();
			levels.put( i, storage );
		}
	}
	
}
