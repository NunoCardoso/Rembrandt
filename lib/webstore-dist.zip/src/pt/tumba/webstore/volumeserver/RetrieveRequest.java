package pt.tumba.webstore.volumeserver;

import java.io.File;



public class RetrieveRequest extends Request {
	
	public RetrieveRequest(File file) {
		super(file);
	}
}