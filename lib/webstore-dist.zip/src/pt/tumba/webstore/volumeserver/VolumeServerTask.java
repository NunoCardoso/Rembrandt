package pt.tumba.webstore.volumeserver;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.util.Arrays;
import java.util.Vector;

import pt.tumba.webstore.Content;
import pt.tumba.webstore.Key;
import pt.tumba.webstore.WebStore;
import pt.tumba.webstore.common.Compressor;
import pt.tumba.webstore.common.Header;
import pt.tumba.webstore.common.BlockFilter;
import pt.tumba.webstore.common.OverloadKey;


/**
 * Represents a task. 
 */
public class VolumeServerTask extends Thread {
	
	Socket socket;
	VolumeServer vsd;
					
	public VolumeServerTask(Socket socket, VolumeServer vsd) {
		this.socket = socket;
		this.vsd = vsd;
	}

	/**
	 * Store task.
	 */
	public void store(StoreRequest request, ObjectOutputStream out, boolean file_lock) throws Exception {
		
		FileAccess fileaccess = FileAccess.Instance();
		Key key = null;		

		File f = null;
		
		if(file_lock)
			synchronized(vsd) {
				f = vsd.add(request.file);
			}
		else
			f = request.file;

		try {
			synchronized(f) {
				RandomAccessFile ras = fileaccess.getFileDescriptor(request.file,FileAccess.WRITE);
	
				if(ras.length() != 0) {
					// if file exists
					Header header = fileaccess.getHeader(ras);
		
					if(request.storemode != WebStore.FORCE_NEW_POLICY  && header.contentSize() == request.content_length) {
			
						if(request.storemode == WebStore.REGULAR_STORE_POLICY) {
							// considered to be the same file
							fileaccess.setRefCount(ras,FileAccess.REFC_INCREMENT);
							out.writeObject(new OKNotFirst());
						}
						else { // WebStore.COMPARE_CONTENTS_POLICY
							byte[] stored_data = fileaccess.getData(ras).getCompressedContent();
		
							boolean equal = true;
							for(int j = 0; equal && j < stored_data.length; j++)
									if(stored_data[j] != request.data[j])
										equal = false;
				
							if(equal) {
								fileaccess.setRefCount(ras,FileAccess.REFC_INCREMENT);
								out.writeObject(new OK());
							}
							else {
								byte[] data = request.compressor.inflate(request.data);
								key = handleCollision(f,new Content(data),request.compressor,request.storemode);
							}
						}
					}
					else { // WebSTORE.FORCE_NEW_POLICY
						fileaccess.close(ras);
						byte[] data = request.compressor.inflate(request.data);
						key = handleCollision(f,new Content(data),request.compressor,request.storemode);
					}		
				}
				else {
					// if it's a new content
					fileaccess.writeData(ras,request.data,request.header);
					out.writeObject(new OK());
				}
				fileaccess.close(ras);
	
				if(key != null) {
					out.writeObject(key);
					out.flush();
				}	
			}
		}
		catch(Exception ex) {
			out.writeObject(new RemoteError());
			throw ex;
		}
		
		if(file_lock)
			synchronized(vsd) {
				vsd.remove(request.file);	
			}
	}
	
	/**
	 * Get task. 
	 */
	public void get(RetrieveRequest request, ObjectOutputStream out) throws Exception {
		FileAccess fileaccess = FileAccess.Instance();
	
		File f = null;
		synchronized(vsd) {
			f = vsd.add(request.file);	
		}
	
		synchronized(f) {
			if(!f.exists()) {
				out.writeObject(new NotFound());
				return;
			}
   
			try {
			   RandomAccessFile ras = fileaccess.getFileDescriptor(f,FileAccess.READ);
			   CompressedContent ret = fileaccess.getData(ras);
				fileaccess.close(ras);
			   out.writeObject(ret);
			}
			catch(Exception ex) {
			   throw ex;
			}
		}
	
		synchronized(vsd) {
			vsd.remove(request.file);	
		}
	
		out.writeObject(new OK());
	}
		
		
	/**
	  * Delete task.
	  */
	public void delete(DeleteRequest request, ObjectOutputStream out) throws Exception {
		FileAccess fileaccess = FileAccess.Instance();
			
		File f = null;
		synchronized(vsd) {
			f = vsd.add(request.file);	
		}
		
		synchronized(f) {
			if(!f.exists()) {
				out.writeObject(new NotFound());
				return;
			}
		
			try {
				RandomAccessFile ras = fileaccess.getFileDescriptor(f,FileAccess.WRITE);

				Header header = fileaccess.getHeader(ras);

				if(header.refCounter() == 1) {
					 fileaccess.close(ras);
					 if(!f.delete()) {
						 vsd.log("Error: It wasn't possible to delete the file " + f + ".");
					 }
				 }
				 else {
					 fileaccess.setRefCount(ras,FileAccess.REFC_DECREMENT);
					 fileaccess.close(ras);
				 }
			 }
			 catch(Exception ex) {
				 throw ex;
			 }
		}
		
		synchronized(vsd) {
			vsd.remove(request.file);	
		}
		
		out.writeObject(new OK());
	}
	
	/**
	 * Exists task.
	 */
	public void exists(ExistsRequest request, ObjectOutputStream out, ObjectInputStream in)
	throws Exception {
		FileAccess fileaccess = FileAccess.Instance();
		
		String dir = request.file.getAbsolutePath();
		String dir1 = dir.substring(dir.lastIndexOf(File.separatorChar) + 1);
		BlockFilter filter = new BlockFilter(dir1);
        
		String dir2 = dir.substring(0,dir.lastIndexOf(File.separatorChar));
		File f = new File(dir2);
        
		File[] match = f.listFiles(filter);
	
		boolean ret = false;
		try {		
			for(int i = 0; !ret && i < match.length; i++) {
				synchronized(vsd) {
					f = vsd.add(match[i]);
				}
				
				synchronized(f) {
					if(f.exists()) {	
						RandomAccessFile ras = fileaccess.getFileDescriptor(match[i],FileAccess.READ);
						Header header = fileaccess.getHeader(ras);
						if(header.contentSize() == request.contentlength)
							ret = true;
						fileaccess.close(ras);
					}
					
					/* if the content wasn't found */
					if(ret) {
				
						/* if it is not a Regular Store, the content must be sent */
						if(request.POLICY != WebStore.REGULAR_STORE_POLICY) {
							out.writeObject(new OK());
								
							/* a Store Request is received, and it is 'forwarded' to store() */
							StoreRequest sr = (StoreRequest) in.readObject();
							store(sr,out,false);
							vsd.log("Store: " + request);
							
							/* store() sent the OK/Key. */
							return; 
						}
						else { // REGULAR_STORE_POLICY
							incRefCount(f);
							out.writeObject(new OKNotFirst());
						}
					}				
				} // sync f
				
				synchronized(vsd) {
					vsd.remove(match[i]);	
				}
			} // for
			
			/* the content wasn't found */
			if(!ret)
				out.writeObject(new NotFound());	
		}
		catch(Exception ex) {
			throw ex;
		}
	}
	
	/**
	 * Increments the reference counter of a file. No file locking. To be used with exists().
	 */
	private void incRefCount(File file) throws Exception {
		FileAccess fileaccess = FileAccess.Instance();
		RandomAccessFile ras = fileaccess.getFileDescriptor(file,FileAccess.WRITE);
		fileaccess.setRefCount(ras,FileAccess.REFC_INCREMENT);
		fileaccess.close(ras);
	}
	
	/**
	 * Handles a collision, and stores the content.
	 *
	 * @param file File corresponding to the content that is colliding.
	 * @param content Content related with the collision.
	 * @param compressor Compressor to use.
	 * @param storemode Semantic.
	 *
	 * @return Key Key for the stored content.
	 */

   public Key 
   handleCollision(File file, Content content, Compressor compressor, int storemode)
   throws Exception {
	   
	   Key ret = null;
	   FileAccess fileaccess = FileAccess.Instance();

	   try {
		   long content_length = content.getData().length;
	
		   String dir = file.getAbsolutePath();
		   String dir1 = dir.substring(dir.lastIndexOf(File.separatorChar) + 1);
		   BlockFilter filter = new BlockFilter(dir1);
    
		   String dir2 = dir.substring(0,dir.lastIndexOf(File.separatorChar));
		   File f = new File(dir2);
    
		   File[] match = f.listFiles(filter);

		   Vector collision_numbers = new Vector();
    
		   for(int i = 0; i < match.length && ret == null; i++) {
				
				if(match[i].equals(file))
					continue;
					
		   		RandomAccessFile ras = fileaccess.getFileDescriptor(match[i],FileAccess.WRITE);

			   if(ras.length() != 0) {
				   String path = match[i].getName();
				   boolean collision = path.indexOf('.') != -1;
				   Integer col_n = null;
            
				   if(collision) {              
					   col_n = Integer.valueOf(path.substring(path.indexOf('.') + 1)); 
					   collision_numbers.addElement(col_n);
				   }

				   if(storemode != WebStore.FORCE_NEW_POLICY) {
					   Header h = fileaccess.getHeader(ras);
			
					   if(h.contentSize() == content_length) {
						   if(storemode == WebStore.REGULAR_STORE_POLICY) {
							   fileaccess.setRefCount(ras,FileAccess.REFC_INCREMENT);
							   ret = collision ? 
										   new OverloadKey(vsd.volume.volId(),content.getSignature(),false,col_n.intValue()) :
										   new Key(vsd.volume.volId(),content.getSignature(),false);
						   }
						   else {  // WebStore.FORCE_COMPARE                    									
							   byte[] stored_data = fileaccess.getData(ras).getCompressedContent();
							   byte[] data = compressor.deflate(content.getData());
					
							   boolean equal = true;
							   for(int j = 0; equal && j < stored_data.length; j++)
								   if(stored_data[j] != data[j])
									   equal = false;

							   if(equal) {
								   ret = collision ? 
										   new OverloadKey(vsd.volume.volId(),content.getSignature(),true,col_n.intValue()) :
										   new Key(vsd.volume.volId(),content.getSignature(),true);
							   }
						   }
					   }
				   }
				   fileaccess.close(ras);
			   }
			   else {
			   		// not supposed to happen
			   		fileaccess.close(ras);
			   		match[i].delete();
			   }
		   }

		   // in case that a content with the same size wasn't found
		   if(ret == null) {

			   int lowest = -1;
         
			   if(collision_numbers.size() == 0)
				   lowest = 0;
			   else {
				   Object[] o = collision_numbers.toArray();
				   Arrays.sort(o);

				   int i = 0;
				   for(; i < o.length && lowest == -1; i++)
					   if(((Integer) o[i]).intValue() != i)
						   lowest = i;
        
				   // no "holes"
				   if(lowest == -1)
					   lowest = i;
			   }

			   File newfile = new File(file.getPath() + "." + lowest);
			   RandomAccessFile ras = fileaccess.getFileDescriptor(newfile,FileAccess.WRITE);
			   Header h = new Header("1",compressor.toString(),content_length,1);
			   byte[] data = compressor.deflate(content.getData());

			   fileaccess.writeData(ras,data,h);
			   fileaccess.close(ras);
        
			   ret = new OverloadKey(vsd.volume.volId(),content.getSignature(),true,lowest);
		   }
	   }
	   catch(Exception ex) {
		   throw ex;
	   }
	   
	   return ret;
   }
   
   
   /**
	* Thread.run()
	*/
   public void run() {
	   synchronized(vsd) {
		   vsd.incThreads();
		   // if there are too many threads executing, this one stays sleeping 
		   if(vsd.threads > vsd.volume.maxThreads()) {
			   try {
				   vsd.wait();	
			   }
			   catch(InterruptedException ex) {
				   ex.printStackTrace(); // for debug
			   }
		   }
	   }
	
	   Request request = null;
	   ObjectOutputStream out = null;
	   ObjectInputStream in = null;
	
	   try {	
		   out = new ObjectOutputStream(socket.getOutputStream());
		   in = new ObjectInputStream(socket.getInputStream());
		
		   request = (Request) in.readObject();
	   }
	   catch(Exception ex1) {
		   // ERRO NO SOCKET
		   vsd.log("Socket Error: " + ex1.getMessage());
		   return;
	   }
	
	   try {
		  
			// change the request.file path to add the prefix WEBSTORE_DATA
			request.file = new File(vsd.WEBSTORE_DATA + File.separatorChar + request.file);
		
		   if(request instanceof StoreRequest) {					
			   StoreRequest req = (StoreRequest) request;
			   store(req,out,true);
			   vsd.log("Store: " + req);
		   }
		   else
			   if(request instanceof RetrieveRequest) {
				   RetrieveRequest req = (RetrieveRequest) request;
				   get(req, out);
				   vsd.log("Retrieve: " + req);
			   }
			   else
				   if(request instanceof DeleteRequest) {
					   DeleteRequest req = (DeleteRequest) request;
					   delete(req,out);
					   vsd.log("Delete: " + req);
				   }
				   else		
					   if(request instanceof ExistsRequest) {
						   ExistsRequest req = (ExistsRequest) request;
						   exists(req, out, in);
						   vsd.log("Exists: " + req);
					   }
					   else 
						   vsd.log("Class Error: " + request);
	   }
	   catch(Exception ex2) {
		   try {
			   out.writeObject(new RemoteError());
			   vsd.log("Error:" + ex2.getMessage());
		   }
		   catch(IOException ex21) {
			   vsd.log("Error: " + ex21.getMessage() + ": [" + request.getClass() + "] " + request);
		   }
		
		   vsd.log("Error: " + ex2.getMessage() + ": [" + request.getClass() + "] " + request);
	   }
	
	   try {
		   out.close();
		   in.close();
		   socket.close();
	   }
	   catch(Exception ex2) {
		   // ERRO NO SOCKET
		   vsd.log("Socket Error: " + ex2.getMessage());
	   }
	
	   synchronized(vsd) {
		   vsd.decThreads();
		   // wakes up threads waiting
		   vsd.notifyAll();
	   }
   } 
   }