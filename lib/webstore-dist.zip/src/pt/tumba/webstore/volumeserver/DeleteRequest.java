package pt.tumba.webstore.volumeserver;

import java.io.File;



public class DeleteRequest extends Request {
	
	public DeleteRequest(File file) {
		super(file);
	}
}