package pt.tumba.webstore.exceptions;

import pt.tumba.webstore.Key;



/**
 * Thrown when a given Key is not valid for the WebStore instance in use.
 * 
 * @author Andre Santos, XLDB
 */
public class InvalidKey extends Exception {

   public InvalidKey(Key key) {
        super("Invalid key: " + key.toString());
    }    
}
