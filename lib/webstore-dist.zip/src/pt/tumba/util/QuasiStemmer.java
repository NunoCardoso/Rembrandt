/*
 * Created on 3/Mai/2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package pt.tumba.util;

import java.io.*;
import java.util.*;

/**
 * @author bmartins
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class QuasiStemmer {

	BloomFilter filter;
	
	public QuasiStemmer ( ) {
		filter = new BloomFilter("5:10:1111111111");
	}
	
	public QuasiStemmer ( File file ) {
		try {
		filter = new BloomFilter(10000000);
		BufferedReader in = new BufferedReader(new FileReader(file));
		String word;
		Object trash = new Object();
		int pos;
		int numWords = 0;
		int occur;
		while ((word = in.readLine()) != null) {
			numWords++;
			pos = word.indexOf(":");
			occur = 1;
			if (pos != -1) {
				occur = (new Integer(word.substring(pos + 1).trim())).intValue();
				word = word.substring(0, pos).trim();
			}
			word = word.toLowerCase();
			filter.put(word);
		}
		in.close();
		} catch ( Exception e ) {}
	}

	public QuasiStemmer ( String filters ) {
		filter = new BloomFilter(filters);
	}

	public boolean exceptions ( String word ) {
	 if(word.equals("golfinho")) return true;
	 else if(word.equals("campe�o")) return true;
	 else if(word.equals("universo")) return true;
	 else if(word.equals("universidade")) return true;
	 return false;
	}

    public String normalization ( String word ) {
    	if (word.endsWith("a") || word.endsWith("e")) {
			String wordAux = word.substring(0,word.length()-1) + "o";
			if(filter.hasKey(wordAux)) return wordAux;
    	}
		if (word.endsWith("e")) {
			String wordAux = word.substring(0,word.length()-1) + "a";
			if(filter.hasKey(wordAux)) return wordAux;
		}
		return word;
    }

	public String stem ( String word ) {
		String word2 = word.toLowerCase();
		if(exceptions(word2)) return word2;
		if(exceptions(normalization(word2))) return normalization(word2);
		String words = word.toLowerCase();
	
		while ( word2.length()>4) {
			 word2 = word2.substring(0,word2.length()-1);
			 if(exceptions(word2)) return word2;
			 if(exceptions(normalization(word2))) return normalization(word2);
			 if(filter.hasKey(word2)) words = word2;
			 else if(word2.endsWith("a")) {
			 	String wordAux = word2.substring(0,word2.length()-1) + "o";
				if(filter.hasKey(wordAux)) {
					word2 = wordAux;
					words = word2; 
			 	}
			 } else if(word2.endsWith("o")) {
			   String wordAux = word2.substring(0,word2.length()-1) + "a";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   }
			 } else if(word2.endsWith("u")) {
			   String wordAux = word2.substring(0,word2.length()-1) + "o";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   }
			 } else if(word2.endsWith("�")) {
			   String wordAux = word2.substring(0,word2.length()-1) + "a";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   }
			 } else if(word2.endsWith("�")) {
			   String wordAux = word2.substring(0,word2.length()-1) + "e";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   }
			} else if(word2.endsWith("�e")) {
			   String wordAux = word2.substring(0,word2.length()-2) + "�o";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   }
			} else if(word2.endsWith("�e")) {
			   String wordAux = word2.substring(0,word2.length()-2) + "�o";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   }
			 } else if(word2.endsWith("�n")) {
				String wordAux = word2.substring(0,word2.length()-2) + "�o";
				if(filter.hasKey(wordAux)) {
					word2 = wordAux;
					words = word2; 
				}
			 } else if(word2.endsWith("�")) {
				String wordAux = word2.substring(0,word2.length()-1) + "o";
				if(filter.hasKey(wordAux)) {
					word2 = wordAux;
					words = word2; 
				}
			} else if(word2.endsWith("�")) {
			   String wordAux = word2.substring(0,word2.length()-1) + "o";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   }
			} else if(word2.endsWith("i")) {
			   String wordAux = word2.substring(0,word2.length()-1) + "o";
			   if(filter.hasKey(wordAux)) {
				   word2 = wordAux;
				   words = word2; 
			   } else {
   		         wordAux = word2.substring(0,word2.length()-1) + "a";
			     if(filter.hasKey(wordAux)) {
				    word2 = wordAux;
				    words = word2; 
			     }else {
					wordAux = word2.substring(0,word2.length()-1) + "e";
					if(filter.hasKey(wordAux)) {
						word2 = wordAux;
						words = word2; 
					}
			     }
			   }
			}
		}
		return normalization(words);
	}

    public static void main ( String args[] ) throws Exception {
   		QuasiStemmer stemmer = new QuasiStemmer(new File(args[0]));
   		if(args.length>1) System.out.println(stemmer.stem(args[1]));
   }

}