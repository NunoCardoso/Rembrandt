/**
 * Content.java
 */
package pt.tumba.webstore;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import pt.tumba.util.RabinHashFunction64;


/**
 * Represents a content that can be stored in WebStore.
 * 
 * @author Andre Santos, XLDB
 * 
 * @see WebStore
 */
public class Content implements Serializable {

    // content's data
    private byte[] stream;

    // signature
    private long signature;
    
	/**
	  * Creates a new instance from a byte array.
	  *
	  * @param data Content's bytes;
	  */
	public Content(byte[] data) {
		stream = data;
		RabinHashFunction64 rabin = new RabinHashFunction64();
		signature = rabin.hash(stream);
	}
		
	/**
	 * Creates a new content from an InputStream.
	 *
	 * @throws IOException If an error when reading from the InputStream occurs.
	 */
	public Content(InputStream is) throws IOException {
		int len = is.available();
		stream = new byte[len];
		is.read(stream);
		RabinHashFunction64 rabin = new RabinHashFunction64();
		signature = rabin.hash(stream);
	}
	
    /**
     * Returns the data corresponding to the content.
     *
     * @return The content's bytes.
     */
    public byte[] getData() {
        return stream;
    }

	/**
	 * Returns a stream corresponding to the content's data.
	 * 
	 * @return The content's bytes.
	 */
	public InputStream getInputStream() {
		return new ByteArrayInputStream(stream);
	}

    /**
     * Returns the file where this content should be placed,
     * given its signature, and the WebStore directory tree depth.
     *
     * @param key A key corresponding to the Content.
     * @param depth Webstore directory tree depth.     
     *
     * @return A <i>File</i> instance representing the file.
     */
	static String getLocation(Key key, int depth) {
        String hexSig = key.hexSignature();        
        String path = "";
        int i = 0;

        while(depth > 0) {
            path += hexSig.substring(i,i + 2) + File.separatorChar;
            depth--;
            i += 2;
        }

        path += hexSig.substring(i);

        return path;
    }

    /**
     * Returns the content's signature (computed using Rabin's Fingerprint algorithm).
     *
     * @return A 64-bit signature.
     */
    public long getSignature() {
        return signature;
    }

    /**
     * Returns a string representation of this content.
     *
     * @return The content's signature represented in hexadecimal.
     */
    public String toString() {
    	Key k = new Key(null,signature,true);
        return k.hexSignature();
    }
    
    /**
     * Is the given content equal?
     * 
     * @param o Object to compare.
     */
    public boolean equals(Object o) {
		boolean equals = false;
    	if(o instanceof Content) {
    		Content content = (Content) o;
    		equals = true;
			for(int i = 0; 
    			equals && i < stream.length && i < content.stream.length;
    			i++)
    			if(stream[i] != content.stream[i])
    				equals = false;

    	}
    	return equals;
    }

	/**
	 * Returns a hash code based on the content's signature. 
	 */
	public int hashCode() {
		return (int) (signature / 2);
	}
}