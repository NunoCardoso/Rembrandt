/**
 * Key.java
 */
package pt.tumba.webstore;

import java.io.Serializable;

import pt.tumba.webstore.common.*;



/**
 * Represents a key that references a content previously stored in WebStore.
 * 
 * @author Andre Santos, XLDB
 * 
 * @see WebStore
 */
public class Key implements Serializable {

    // Volume
    protected String volume_id;

    // Signature
    protected long signature;
   
    // Is it the first?
    protected boolean first;
    
    
    /**
     * Creates an instance of Key from a volume id and a long.
     *
     * @param volume_id Volume id.
     * @param signature Signature.
     */
    public Key(String volume_id, long signature, boolean first) {
        this.volume_id = volume_id;
        this.signature = signature;
        this.first = first;
    }
    
    
    /**
     * Creates a new key from a string which contains an external representation of a key.
     * 
     * @param externalFormat External representation of a key.
     */
    public static Key toKey(String externalFormat) {
		int i_f = externalFormat.indexOf('%');
		int i_a = externalFormat.indexOf('@');
		int i_c = externalFormat.indexOf('.');
		
		if(i_a == -1 || externalFormat.length() == 0)
			return null;
			
		boolean is_first = i_f != -1;
		
		int collision = -1;
		
		long signature = 0;
		
		if(i_c != -1) {
			try {
				collision = Integer.valueOf(externalFormat.substring(i_c + 1,i_a)).intValue();
			}
			catch(NumberFormatException ex) {
				return null;
			}
			signature = Long.valueOf(externalFormat.substring(0,i_c)).longValue();
		}
		else {
				signature = Long.valueOf(externalFormat.substring(0,i_a)).longValue();
		}
		
		String volume_id = null;
		if(is_first)
			volume_id = externalFormat.substring(i_a + 1,i_f);
		else
			volume_id = externalFormat.substring(i_a + 1);
		
		
		if(collision == -1)
			return new Key(volume_id,signature,is_first);
		else
			return new OverloadKey(volume_id,signature,is_first,collision); 
    }
    
    
    /**
     * Returns an external representation of the key.
     * 
     * @return Something in the form: <i>signature</i>{<i>.n</i>}<i>@volume</i>{<i>%</i>}.
     */
    public String toExternalFormat() {
		return signature + "@" + volume_id + (first ? "%" : "");
    }
    
    /**
     * Returns the string representation of the key; the same as in toExternalFormat().
     *
     * @return Something in the form: <i>signature</i>{<i>.n</i>}<i>@volume</i>{<i>%</i>}.
     */
    public String toString() {
        return toExternalFormat();
    }

    /**
     * Returns the volume (id) where the content associated to the key is stored. 
     *
     * @return A string containing the volume's id.
     */
    public String getVolumeID() {
        return volume_id;
    }

    /**
     * Returns the signature of the content associated to the key.
     *
     * @return A 64-bit number corresponding to the signature.
     */
    public long getSignature() {
        return signature;
    }

    /**
     * Returns a 16-character string with the hexadeximal key's signature representation. 
     *
     * @return A 16-character string; if the key is related with a collision, it returns a larger string, in the form '****************.collision_number'.
     */
    protected String hexSignature() {
        String ret = Long.toHexString(signature);
        
        int ret_len = ret.length();
        while(ret_len++ != 16)
            ret = "0" + ret;

        return ret;
    }

    /**
     * Does this key corresponds to a file overload?
     *
     * @return true if yes.
     */
    boolean isOverload() {
        return this instanceof OverloadKey;
    }

    /**
     * If there are duplicated contents of the associated content, was this one the first to be stored?  
     */
    public boolean isFirst() {
    	return first;
    }
}
