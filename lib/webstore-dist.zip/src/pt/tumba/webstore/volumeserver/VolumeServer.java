package pt.tumba.webstore.volumeserver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import pt.tumba.webstore.Volume;
import pt.tumba.webstore.common.ConfigParser;
import pt.tumba.webstore.exceptions.InvalidConfigFile;

/**
 * @author Andre Santos, XLDB
 *
 * WebStore volume server.
 */
class VolumeServer {

	// volume
	Volume volume;

	// locked files
	List locks;

	// logger
	Logger logger;

	// number of running threads
	int threads;
	
	// WEBSTORE_DATA
	String WEBSTORE_DATA;
	
	/**
	 * Represents a file that is locked.
	 */
	private class FileLocked {
		public File file;
		public int references;

		public FileLocked(File file) {
			this.file = file;
			this.references = 1;
		}

		public boolean equals(Object o) {
			return ((FileLocked) o).file.equals(file);
		}
		
		public int hashCode() {
			return file.hashCode();	
		}
	}

	/**
	 * Creates a new Volume Server. 
	 * 
	 * @param volume Volume to serve.
	 * @param WEBSTORE_DATA Volumes root location.
	 */
	VolumeServer(Volume volume, String WEBSTORE_DATA) {
		this.volume = volume;
		locks = new Vector();
		this.threads = 0;
		this.WEBSTORE_DATA = WEBSTORE_DATA;
	}

	/**
	 * Adds a file to the list of locked files.
	 */
	File add(File file) {
		FileLocked fl = new FileLocked(file);
		if (!locks.contains(fl)) {
			locks.add(fl);
			return fl.file;
		} else {
			FileLocked fl2 = (FileLocked) locks.get(locks.indexOf(fl));
			fl2.references++;
			return fl2.file;
		}
	}

	/**
	 * Removes a file from the list of locked files.
	 */
	void remove(File file) {
		FileLocked fl = new FileLocked(file);
		if (locks.contains(fl)) {
			FileLocked fl2 = (FileLocked) locks.get(locks.indexOf(fl));
			if (fl2.references > 1)
				fl2.references--;
			else
				locks.remove(fl2);
		} else
			System.err.println("ERROR lock"); // for debug
	}

	/**
	 * Logs a message in the log file.
	 */
	synchronized void log(String msg) {
		logger.info(msg);
	}

	/**
	 * Increase the number of threads counter.
	 */
	synchronized void incThreads() {
		threads++;
	}

	/**
	 * Decrease the number of threads counter.
	 */
	synchronized void decThreads() {
		threads--;
	}


	/**
	 * Main.
	 */
	public static void main(String args[]) {

		if (args.length != 1) {
			System.err.println("Wrong number of arguments.");
			System.exit(1);
		}

		String WEBSTORE_HOME = System.getProperty("WEBSTORE_HOME");
		if(WEBSTORE_HOME == null) {
			System.err.println("Property WEBSTORE_HOME not defined. Quiting.");
			System.exit(1);
		}
		
		if(WEBSTORE_HOME.charAt(WEBSTORE_HOME.length() - 1) == File.separatorChar)
			WEBSTORE_HOME.substring(0,WEBSTORE_HOME.length() - 1);
		
		String WEBSTORE_DATA = System.getProperty("WEBSTORE_DATA");
		if(WEBSTORE_DATA == null) {
			System.err.println("Property WEBSTORE_DATA not defined. Quiting.");
			System.exit(1);
		}		
		
		if(WEBSTORE_DATA.charAt(WEBSTORE_DATA.length() - 1) == File.separatorChar)
			WEBSTORE_DATA.substring(0,WEBSTORE_DATA.length() - 1);
		
		// volume root
		String volRoot = WEBSTORE_DATA + File.separatorChar + args[0];

		String CONFIG_FILE = System.getProperty("CONFIG_FILE");
		if(CONFIG_FILE == null) {
			System.err.println("Property CONFIG_FILE not defined. Quiting.");
			System.exit(1);
		}	
		
		File cfg_file = new File(CONFIG_FILE);

		ConfigParser parser = new ConfigParser();
		
		try {
			parser.parse(cfg_file);
		} catch (InvalidConfigFile ex) {
			System.err.println(ex.getMessage());
			System.exit(1);
		}

		Volume[] vols = parser.getVolumes();
		Volume vol = null;
		InetSocketAddress server = null;

		int xx = volRoot.lastIndexOf(File.separatorChar);
		String path = "";
		if (xx != -1) {
			path = volRoot.substring(0, xx + 1);
			volRoot = volRoot.substring(xx + 1);
		}

		for (int i = 0; vol == null & i < vols.length; i++)
			if (vols[i].toString().equals(volRoot)) {
				vol = vols[i];
				server = vols[i].host();
			}

		
		if (vol == null) {
			System.err.println(
				"No matching volume found in config file for \""
					+ path
					+ volRoot
					+ "\".");
			System.exit(1);
		}

		VolumeServer vsd = new VolumeServer(vol,WEBSTORE_DATA);
		File log4j_config_file = new File(WEBSTORE_HOME + File.separatorChar + 
			"conf" + File.separatorChar + "daemonlog.properties");

		try {
			PrintStream ps =
				new PrintStream(new FileOutputStream(log4j_config_file));
			ps.println("log4j.appender.dest.File=" + vsd.volume.logFile());
			ps.println("log4j.appender.dest.layout=org.apache.log4j.PatternLayout");
			ps.println("log4j.appender.dest=org.apache.log4j.RollingFileAppender");
			ps.println("log4j.rootCategory=INFO, dest");
			ps.println("log4j.appender.dest.layout.ConversionPattern=%d - %m%n");
			ps.close();
		} catch (Exception ex) {
			vsd.log("Error: " + ex.getMessage());
		}

		PropertyConfigurator pc = new PropertyConfigurator();
		LogManager.resetConfiguration();
		pc.doConfigure(
			log4j_config_file.getAbsolutePath(),
			LogManager.getLoggerRepository()
			);
		vsd.logger = Logger.getRootLogger();

		ServerSocket ss = null;
		try {
			ss = new ServerSocket(vol.host().getPort());
		}
		catch(IOException ex) {
			System.err.println(ex.getMessage());
			System.exit(1); 
		}
		
		try {
			System.out.println("Volume server for '" + vol.volId() + 
				"' listening on port " + vol.host().getPort() + ".");
			while (true) {
				VolumeServerTask c = new VolumeServerTask(ss.accept(),vsd);
				c.start();
			}
		} catch (IOException ex) {
			vsd.log("Socket Error: " + ex.getMessage());
		}
	}
}