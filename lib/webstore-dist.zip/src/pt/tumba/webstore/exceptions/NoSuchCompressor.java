package pt.tumba.webstore.exceptions;



/**
 * Thrown when the user tries to use a not assigned compressor code when performing the <i>store</i> operation, or when there is no compressor available to decompress a previously stored content.
 * 
 * @author Andre Santos, XLDB
 */
public class NoSuchCompressor extends Exception {

    public NoSuchCompressor(int code) {
        super("There's no compressor configured with code '" + code + "'.");
    }

    public NoSuchCompressor(String compress_mode) {
        super("There's no compressor available for the compression algorithm '" + compress_mode + "'.");
    }    
}
