package pt.tumba.webstore.exceptions;



/**
 * Thrown when a volume is unreachable for some reason.
 * This can happen when a NFS mount is down or due to other network problems.
 * 
 * @author Andre Santos, XLDB
 */
public class VolumeUnreachable extends Exception {

	/**
	 * Creates a new Volume Unreachable Exception from a string.
	 *
	 * @param msg Exception reason.
	 */
	public VolumeUnreachable(String msg) {
		super(msg);
	}
}
