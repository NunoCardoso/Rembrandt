package pt.tumba.webstore.exceptions;


/**
 * Thrown when there was a decompression error during the <i>retrieve</i> operation.
 * This can happen when the stored compressed content is corrupted, or has a wrong compression mode assigned.
 * 
 * @author Andre Santos, XLDB
 */
public class DecompressionError extends Exception {

    public DecompressionError(String msg) {
        super(msg);
    }
}