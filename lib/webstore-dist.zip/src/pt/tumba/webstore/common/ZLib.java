/**
 * ZLib.java
 *
 * @author André� Santos, XLDB
 */

package pt.tumba.webstore.common;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import pt.tumba.webstore.exceptions.DecompressionError;


public class ZLib extends Compressor {

    /**
     * Same behavior as defined in interface <i>Compressor</i>.
     */
    public byte[] deflate(byte[] data) {

        Deflater compressor = new Deflater();
        compressor.setLevel(Deflater.BEST_SPEED);
        compressor.setInput(data);
        compressor.finish();

        ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length);
        byte[] buf = new byte[1024];
        while (!compressor.finished()) {
            int count = compressor.deflate(buf);
            bos.write(buf, 0, count);
        }
        try {
            bos.close();
        }
        catch(IOException e) {
            System.err.println(e.getMessage());
        }

        return bos.toByteArray();        
    }

    /**
     * Same behavior as defined in interface <i>Compressor</i>.
     */
    public byte[] inflate(byte[] data) throws DecompressionError {
        Inflater decompressor = new Inflater();
        decompressor.setInput(data);

        ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length);

        byte[] buf = new byte[1024];
        while(!decompressor.finished()) {
            try {
                int count = decompressor.inflate(buf);
                bos.write(buf, 0, count);
            }
            catch(DataFormatException e) {
                throw new DecompressionError("Zlib error: " + e.getMessage());
            }
        }
        try {
            bos.close();
        }
        catch (IOException e) {
            System.err.println(e.getMessage());
        }
        return bos.toByteArray();        
    }

    /**
     * Returns the compression algorithm.
     *
     * @return A string that is the compressor name.
     */
    public String toString() {
        return "ZLib";
    }
}