
package pt.tumba.webstore.tests;

import java.io.File;
import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import pt.tumba.util.RabinHashFunction64;

public class FileAverageSize {

	static void all_recursive(File root,Vector ret) {
			File[] f = root.listFiles();
		
			for(int i = 0; i < f.length; i++)
				if(f[i].isDirectory())
					all_recursive(f[i],ret);
				else
					ret.addElement(f[i]);
	}
	
	public static void main(String[] args) {
		
			File dir = new File(args[0]);
	
			Vector vec = new Vector();
			all_recursive(dir,vec);
		
			File[] files = new File[vec.size()];
			for(int i = 0; i < vec.size(); i++)
				files[i] = (File) vec.elementAt(i);
			
			long sum = 0;
			
			Hashtable h = new Hashtable();
			
			RabinHashFunction64 rabin = new RabinHashFunction64();
			
			Long[] keys = new Long[files.length];
			
			for(int i = 0; i < files.length; i++) {
				sum += files[i].length();
				byte[] bytes = null;
				try {
					FileInputStream fis = new FileInputStream(files[i]);
					bytes = new byte[fis.available()]; 
					fis.read(bytes);
					fis.close();
				}
				catch(Exception ex) {
					ex.printStackTrace();
				}
				
				keys[i] = new Long(rabin.hash(bytes));
				
				if(h.containsKey(keys[i])) {
					Integer igr = new Integer(((Integer) h.get(keys[i])).intValue() + 1);
					h.put(keys[i],igr);
				}
				else
					h.put(keys[i],new Integer(1));
			}
			
			
			Enumeration e = h.elements();
			
			long duplicates = 0;
			int dis_dup = 0;
			while(e.hasMoreElements()) {
				int i = ((Integer) e.nextElement()).intValue();
				if(i > 1) {
					dis_dup++;
					duplicates += i - 1;
				}
			}
			
			System.out.println("Number of files: " + files.length);
			System.out.println("Sum: " + ((float) sum / 1024 / 1024 ) + " Mb");
			System.out.println("Average: " + (sum / files.length / 1024) + " Kb" );
			System.out.println("Distinct: " + ((long) files.length - duplicates));
			System.out.println("Duplication: " + ((float) duplicates / files.length * 100) + "% (" + duplicates + " files)");
			System.out.println("Distinct duplicates: " + dis_dup);
	}

}
