package pt.tumba.webstore.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;

public class NFSCopy {

	static void all_recursive(File root,Vector ret) {
			File[] f = root.listFiles();
		
			for(int i = 0; i < f.length; i++)
				if(f[i].isDirectory())
					all_recursive(f[i],ret);
				else
					ret.addElement(f[i]);
		}

		public static void main(String args[]) {
		
			try {
			
				int n_clients = Integer.valueOf(args[0]).intValue();
				int client = Integer.valueOf(args[1]).intValue();
			
				Vector allfiles = new Vector();
			
				all_recursive(new File(args[2]),allfiles);
			
				Vector list = new Vector();
			
				boolean split = args.length == 4 && args[3].equals("-s");
			
				for(int i = 0; i < allfiles.size(); i++)
					if(split) {
						if(i % n_clients == client)
							list.add(allfiles.elementAt(i));
					}
					else {
						list.add(allfiles.elementAt(i));
					}
				
				String command = null;
				Runtime run = Runtime.getRuntime();
				long time = System.currentTimeMillis();
				
				for(int i = 0; i < list.size(); i++) {
					FileInputStream fis = new FileInputStream(((File) list.elementAt(i)).getAbsolutePath());
					FileOutputStream fos = new FileOutputStream("/home/als/tmp/" + ((File) list.elementAt(i)).getName());
					
					byte[] data = new byte[fis.available()];
					fis.read(data);
					fos.write(data);
					fis.close();
					fos.close();
				
					/* EXEC
					command = "cp " + ((File) list.elementAt(i)).getAbsolutePath() + " /home/als/tmp/.";	
					Process p = run.exec(command);
					p.waitFor();
					*/
				}
				
				double time2 = (System.currentTimeMillis() - time) / 1000.0;
				System.out.println("client " + client + " time: " + time2);
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		
		
}
