package pt.tumba.util;

public final class BitUtils {

	private static final BitUtils _theInstance = new BitUtils();

	/** Precomputed least significant bits for bytes (-1 for 0 ). */
	public static final int BYTELSB[] = {
	    -1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
	    4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0
	};
	    

	/** Precomputed most significant bits for bytes (-1 for 0 ). */
	public static final int BYTEMSB[] = {
		-1, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 
		4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
		5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
		5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
		6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
		7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7
	};

	public static BitUtils getInstance() {
		return _theInstance;
	}

	/** Maps integers bijectively into natural numbers.
	 * 
	 * <P>This method will map a negative integer <var>x</var> to -2<var>x</var>-1 and
	 * a nonnegative integer <var>x</var> to 2<var>x</var>. It can be used to save arbitrary
	 * integers using the standard coding methods (which all work on natural numbers).
	 * 
	 * <P>The inverse of the above map is computed by {@link #nat2int(int)}
	 *
	 * @param x an integer.
	 * @return the argument mapped into natural numbers.
	 * @see #nat2int(int)
	 */

	public static int int2nat( int x ) {
		return x >= 0 ? x << 1 : ( -x << 1 ) - 1;
	}

	/** Computes the least significant bit of an integer.
	 *
	 * @param x an integer.
	 * @return the least significant bit of the argument (-1 for 0).
	 */

	public static int leastSignificantBit( int v ) {
		int x = v;
		if ( x == 0 ) return -1;
		int bit = 0;
		while ( ( x & 0xFF ) == 0 ) {
			bit += 8;
			x >>>= 8;
		}

		return bit + BYTELSB[ x & 0xFF ];
	}

	/** Computes the least significant bit of a long integer.
	 *
	 * @param x a long integer.
	 * @return the least significant bit of the argument (-1 for 0).
	 */

	public static int leastSignificantBit( long v ) {
		long x = v;
		if ( x == 0 ) return -1;
		int bit = 0;
		while ( ( x & 0xFF ) == 0 ) {
			bit += 8;
			x >>>= 8;
		}

		return bit + BYTELSB[ (int)x & 0xFF ];
	}

	/** Computes the most significant bit of an integer.
	 *
	 * @param x an integer.
	 * @return the most significant bit of the argument (-1 for 0).
	 */

	public static int mostSignificantBit( int v ) {
		int bit = 0;
		int x = v;
		while ( ( x & 0xFFFFFF00 ) != 0 ) {
			bit += 8;
			x >>>= 8;
		}

		return bit + BYTEMSB[ x ];
	}

	/** Computes the most significant bit of a long integer.
	 *
	 * @param x a long integer.
	 * @return the most significant bit of the argument (-1 for 0 ).
	 */

	public static int mostSignificantBit( long v ) {
		int bit = 0;
		long x = v;
		while ( ( x & 0xFFFFFFFFFFFFFF00L ) != 0 ) {
			bit += 8;
			x >>>= 8;
		}

		return bit + BYTEMSB[ (int)x ];
	}

	/** Maps natural numbers bijectively into integers.
	 * 
	 * <P>This method computes the inverse of {@link #int2nat(int)}
	 *
	 * @param x a natural  number.
	 * @return the argument mapped into an integer.
	 * @see #int2nat(int)
	 */

	public static int nat2int( int x ) {
		return x % 2 == 0 ? x >> 1 : -( ( x + 1 ) >> 1 );
	}

	private BitUtils() {}

}
