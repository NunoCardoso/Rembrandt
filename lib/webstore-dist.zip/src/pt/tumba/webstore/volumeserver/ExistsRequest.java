package pt.tumba.webstore.volumeserver;

import java.io.File;



public class ExistsRequest extends Request {	

	long contentlength;
	
	int POLICY;

	public ExistsRequest(File file, long contentlength, int POLICY) {
		super(file);
		this.contentlength = contentlength;
		this.POLICY = POLICY;
	}
}