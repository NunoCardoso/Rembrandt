package pt.tumba.webstore.volumeserver;


public class NotFound extends ServerReply {

}
