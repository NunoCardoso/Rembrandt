/*
 * Repairable.java
 *
 * Created on December 29, 2002, 4:41 PM
 *
 * Copyright (C) 2003 Thought River North and Thought River South, All Rights 
 * Reserved. 
 *
 * Unless explicitly acquired and licensed from Licensor, the contents of this 
 * file are subject to the Reciprocal Public License ("RPL") Version 1.1, or 
 * subsequent versions as allowed by the RPL, and You may not copy or use this 
 * file in either source code or executable form, except in compliance with the 
 * terms and conditions of the RPL. 
 *
 * You may obtain a copy of the RPL (the "License") from the Open Source 
 * Initiative at http://www.opensource.org.
 *
 * All software distributed under the Licenses is provided strictly on an "AS 
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND 
 * THOUGHT RIVER NORTH AND THOUGHT RIVER SOUTH HEREBY DISCLAIM ALL SUCH 
 * WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See 
 * the License for specific language governing rights and limitations under the 
 * License.
 */

package pt.tumba.util.maintenance;

import java.util.*;


/**
 * This interface is implemented by classes that want to be inspected and
 * repaired by the <CODE>MaintenanceRobot</CODE>.  The exact approach with
 * which these methods should be implemented is, of course, undefined, but the
 * implementation should take precautions to ensure that the inspections and
 * corresponding repairs are:
 * <OL>
 * <LI>atomic (the inspection immediately precedes the corresponding repair)
 * <LI>thread-safe
 * <LI>of appropriate complexity and quickness for the method in which they are
 * being performed
 * </OL>
 *
 * @author Brandon Franklin
 * @version $Date: 2003/11/21 15:42:47 $
 */
public interface Repairable {
	
	/**
	 * Instructs the <CODE>Repairable</CODE> object to do inspections and
	 * corresponding repairs that can be considered "quick".  Examples of this
	 * sort of repair include, but are not limited to:
	 * <UL>
	 * <LI>Checking for a null value
	 * <LI>Ensuring that a numerical value is within its allowed range
	 * <LI>Ensuring that a value matches a simple configuration value specified 
	 * in a memory object
	 * </UL>
	 *
	 * @return a <CODE>List</CODE> of <CODE>String</CODE>s describing the
	 * repairs that were made, or an empty <CODE>List</CODE> if none were made
	 */
	List makeQuickRepairs();
	
	/**
	 * Instructs the <CODE>Repairable</CODE> object to do inspections and
	 * corresponding repairs that involve complex analysis.  Examples of this
	 * sort of repair include, but are not limited to:
	 * <UL>
	 * <LI>Checking for a value setting whose current value is based upon some
	 * complex configuration of other values, and correcting it based upon
	 * those other values
	 * <LI>Any inspection and repair that involves interaction with a file
	 * <LI>Any inspection and repair that involves network communication
	 * </UL>
	 *
	 * @return a <CODE>List</CODE> of <CODE>String</CODE>s describing the
	 * repairs that were made, or an empty <CODE>List</CODE> if none were made
	 */
	List makeFullRepairs();
	
}
