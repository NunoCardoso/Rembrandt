/*
 * IrreparableProblemStrategy.java
 *
 * Created on December 30, 2002, 3:09 AM
 *
 * Copyright (C) 2003 Thought River North and Thought River South, All Rights 
 * Reserved. 
 *
 * Unless explicitly acquired and licensed from Licensor, the contents of this 
 * file are subject to the Reciprocal Public License ("RPL") Version 1.1, or 
 * subsequent versions as allowed by the RPL, and You may not copy or use this 
 * file in either source code or executable form, except in compliance with the 
 * terms and conditions of the RPL. 
 *
 * You may obtain a copy of the RPL (the "License") from the Open Source 
 * Initiative at http://www.opensource.org.
 *
 * All software distributed under the Licenses is provided strictly on an "AS 
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND 
 * THOUGHT RIVER NORTH AND THOUGHT RIVER SOUTH HEREBY DISCLAIM ALL SUCH 
 * WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See 
 * the License for specific language governing rights and limitations under the 
 * License.
 */

package pt.tumba.util.maintenance;

/**
 * Implementations of this class can be provided to a <CODE>MaintenanceRobot</CODE>
 * for use when a problem is encountered that the robot does not have the
 * ability to rectify.  These types of problems are identified by one feature:
 * they produce an <CODE>IllegalStateException</CODE> during the inspection and
 * repair phase.  This exception object is supplied to the <CODE>activate</CODE>
 * method of the strategy object as soon as it is encountered, and the strategy
 * object should immediately respond.  A typical response to this sort of
 * problem is a complete system shutdown, as this kind of error represents a
 * <I>very</I> serious situation.
 *
 * @author Brandon Franklin
 * @version $Date: 2003/11/21 15:42:47 $
 */
public interface IrreparableProblemStrategy {
	
	/**
	 * This method is invoked by the <CODE>MaintenanceRobot</CODE> (or, more
	 * specifically, by the currently-running <CODE>Task</CODE> instance) when
	 * a problem has been encountered that the robot does not have the ability
	 * to repair.  It would not be unexpected for a call to this method to
	 * result in a total system shutdown.
	 *
	 * @param ise the exception that was thrown during the inspection and
	 * repair cycle
	 */
	void activate(IllegalStateException ise);
	
}
