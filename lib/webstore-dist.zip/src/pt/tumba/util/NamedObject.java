package pt.tumba.util;

/**
 * This class represents an object type that is unique based on a supplied
 * <CODE>String</CODE> name.  This means that two instances of <CODE>NamedObject</CODE>
 * with the same name will be considered equal by calls to <CODE>equals</CODE>,
 * and will have the same hash code.  Additionally, <CODE>NamedObject</CODE>
 * implements <CODE>Comparable</CODE>, allowing instances to be sorted in
 * ascending alphabetical order by name.  The name of the object itself must not
 * be null, and must be supplied at instantiation time.
 */
public class NamedObject extends Object implements Comparable {
	
	/** The name of this <CODE>NamedObject</CODE> */
	private String name;
	
	
	/**
	 * Creates a new instance of <CODE>NamedObject</CODE> with the given name.
	 *
	 * @param name the name of the new <CODE>NamedObject</CODE>
	 *
	 * @throws IllegalArgumentException if the supplied name is null
	 */
	public NamedObject(final String name) {
		if( name == null ) {
			throw new IllegalArgumentException("NamedObjects cannot have null names!");
		}
		this.name = name;
	}
	
	/**
	 * Sets the name of this <CODE>NamedObject</CODE>.
	 *
	 * @param name the new name of this <CODE>NamedObject</CODE>
	 *
	 * @throws IllegalArgumentException if the supplied name is null
	 */
	public void setName(final String name) {
		if( name == null ) {
			throw new IllegalArgumentException("NamedObjects cannot have null names!");
		}
		this.name = name;
	}
	
	/**
	 * Returns the name of this <CODE>NamedObject</CODE>.
	 *
	 * @return the name of this <CODE>NamedObject</CODE>
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Examines this <CODE>NamedObject</CODE> for equality to the supplied one,
	 * and returns the boolean result.  The equality criterion is the <CODE>NamedObject</CODE>'s
	 * name.
	 *
	 * @param obj the object to be examined for equality
	 *
	 * @return true if the objects are equivalent, false otherwise
	 *
	 * @throws ClassCastException if the supplied object is not an instance of
	 * <CODE>NamedObject</CODE>
	 */
	public boolean equals(final Object obj) {
		if( obj == null ) {
			return false;
		}
		NamedObject otherObject = (NamedObject)obj;
		return getName().equals( otherObject.getName() );
	}
	
	/**
	 * Returns the hash value for this <CODE>NamedObject</CODE>, which will be
	 * generated based on its name.
	 *
	 * @return the hash value for this <CODE>NamedObject</CODE>
	 */
	public int hashCode() {
		return getName().hashCode();
	}
	
	/**
	 * Compares this object with the specified object for order. Returns a negative
	 * integer, zero, or a positive integer as this object is less than, equal to,
	 * or greater than the specified object.
	 *
	 * @param obj the object to compare with this one, which much be an instance
	 * of <CODE>NamedObject</CODE>
	 *
	 * @throws ClassCastException if the supplied object is not and instance of
	 * <CODE>NamedObject</CODE>
	 */
	public int compareTo(final Object obj) {
		return getName().compareTo( ((NamedObject)obj).getName() );
	}
	
}
