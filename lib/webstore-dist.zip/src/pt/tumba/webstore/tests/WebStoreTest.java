package pt.tumba.webstore.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import junit.framework.TestCase;
import pt.tumba.webstore.Content;
import pt.tumba.webstore.Key;
import pt.tumba.webstore.Volume;
import pt.tumba.webstore.WebStore;
import pt.tumba.webstore.exceptions.InvalidConfigFile;



class WebStoreTest extends TestCase implements Cloneable {

	File[] files;
	
	Key[] keys;

	String[] keys_s;
	
	WebStore ws;

	Volume[] vols;

	String cfg_file;

	int n_clients;

	WebStoreTest task;

	String log_file;
	
	public WebStoreTest(String test,File[][] files,String cfg_file,int n_clients,WebStoreTest task,String log_file) 
		throws InvalidConfigFile {
		super(test);		
		this.files = concat(files);
		int keys_len = 0;
		keys = new Key[this.files.length];
		keys_s = new String[this.files.length];
		ws = new WebStore(new File(cfg_file));
		this.log_file = log_file;
		vols = ws.getVolumes(WebStore.WRITABLE);
		this.cfg_file = cfg_file;
		this.n_clients = n_clients;
		this.task = task;
	}
    
	public WebStoreTest(String test,File[] files,String cfg_file,int n_clients,WebStoreTest task,String log_file) 
			throws InvalidConfigFile {
			super(test);		
			this.files = files;
			int keys_len = 0;
			keys = new Key[this.files.length];
			keys_s = new String[this.files.length];
			ws = new WebStore(new File(cfg_file));
			this.log_file = log_file;
			vols = ws.getVolumes(WebStore.WRITABLE);
			this.cfg_file = cfg_file;
			this.n_clients = n_clients;
			this.task = task;
	}
		
	public WebStoreTest(String test,File[] files,String cfg_file,String log_file) throws InvalidConfigFile {
			this(test,files,cfg_file,-1,null,log_file);
	}
    
    public WebStoreTest(String test,String cfg_file,int n_clients,WebStoreTest task) throws InvalidConfigFile {
    		this(test,new File[0],cfg_file,n_clients,task,"webstore.log");
    }
    protected Object clone() {
    	WebStoreTest ret = null;
    	try {
    		ret = new WebStoreTest(getName(),files,cfg_file,n_clients,task,log_file);
    	}
    	catch(InvalidConfigFile ex) {
    		ex.printStackTrace();
    	}
    	
    	ret.keys = keys;
    	return ret;
    }
    
    private File[] concat(File[][] files) {
    	 int total = 0;
    	 
    	 for(int i = 0; i < files.length; i++)
    	 	total += files[i].length;
    	 
    	 File[] ret = new File[total];
    	 
    	 int ret_i = 0;
    	 for(int i = 0; i < files.length; i++)
    	 	for(int j = 0; j < files[i].length; j++)
    	 		ret[ret_i++] = files[i][j];
    	 		
    	 return ret;
    }
    

    
    public void testStore() {	
		
		for(int i = 0; i < files.length; i++) {
			Content cont = null;
			
			try {
				cont = new Content(new FileInputStream(files[i]));	
			}
			catch(IOException ex) {
				System.err.println(ex.getMessage());
			}        
            
			try {
				keys[i] = ws.store(cont);
				
				if(keys[i] != null)
					keys_s[i] = keys[i].toExternalFormat();
				
				//pw.println(keys_s[i]);
			}
			catch(Exception ex) {
				ex.printStackTrace();
				System.out.println(cont + " <--> " + cont.getSignature());
				System.exit(1); 
			}
			
		}
		/*
		try {
			pw.close();
			fos.close();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		*/
    }
    
    public void testStoreVol() {	
		
		for(int i = 0; i < files.length; i++) {
			Content cont = null;
			
			try {
				cont = new Content(new FileInputStream(files[i]));	
			}
			catch(IOException ex) {
				System.err.println(ex.getMessage());
			}        
            
			try {
				keys[i] = ws.store(cont,vols[i % vols.length]);
				
				if(keys[i] != null)
					keys_s[i] = keys[i].toExternalFormat();
				
				//pw.println(keys_s[i]);
			}
			catch(Exception ex) {
				ex.printStackTrace();
				System.out.println(cont + " <--> " + cont.getSignature());
				System.exit(1); 
			}
			
		}
		/*
		try {
			pw.close();
			fos.close();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		*/
    }
    
    public void testStoreForce() {
        ws.setDefaultDuplicatesPolicy(WebStore.FORCE_NEW_POLICY);
        for(int i = 0; i < files.length; i++) {
            Content cont = null;
            try {
                cont = new Content(new FileInputStream(files[i]));
            }
            catch(IOException ex) {
                System.err.println(ex.getMessage());
            }        
            
            try {
                keys[i] = ws.store(cont);
                keys_s[i] = keys[i].toExternalFormat();  
            }
            catch(Exception ex) {
                ex.printStackTrace();
            }
        }
    }
	
	public void testStoreCompare() {
	    ws.setDefaultDuplicatesPolicy(WebStore.COMPARE_CONTENTS_POLICY);
	    for(int i = 0; i < files.length; i++) {
	        Content cont = null;
	        try {
	            cont = new Content(new FileInputStream(files[i]));
	        }
	        catch(IOException ex) {
	            System.err.println(ex.getMessage());
	        }        
	        
	        try {
	            keys[i] = ws.store(cont);
	            keys_s[i] = keys[i].toExternalFormat();  
	        }
	        catch(Exception ex) {
	            ex.printStackTrace();
	        }
	    }
	}	
		  
    public void testRetrieve() {
		long time = System.currentTimeMillis();
		
		for(int i = 0; i < files.length; i++) {
			Content cont1 = null;
			try {
				cont1 = new Content(new FileInputStream(files[i]));
			}
			catch(IOException ex) {
				System.out.println(ex.getMessage());
			}        
            
			Content cont2 = null;
			try {
				//Key iformat = Key.toKey(keys_s[i]);  
				//cont2 = ws.retrieve(iformat);
				cont2 = ws.retrieve(keys[i]);
			}
			catch(Exception ex) {
				System.out.println(ex.getMessage());
				ex.printStackTrace();
			}
			
			assertEquals(cont1,cont2);
		}
		//System.out.println("retrieve (comparing): " + ((System.currentTimeMillis() - time) / 1000) + " seconds.");
    }
    
	public void testRetrieveNoCompare() {
		//long time = System.currentTimeMillis();
		for(int i = 0; i < keys.length; i++) {                    
			Content cont = null;
			try {
				cont = ws.retrieve(keys[i]);
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		//System.out.println("retrieve (writing files): " + ((System.currentTimeMillis() - time) / 1000) + " seconds.");
	}    
    
    public void testDelete() {
    	long time = System.currentTimeMillis();
		for(int i = 0; i < files.length; i++) {
			try {
				ws.delete(keys[i]);
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
		}
		//System.out.println("delete: " + ((System.currentTimeMillis() - time) / 1000) + " seconds.");
    }
    
    
    public void testMultipleClients() {
    	Thread[] clients = new Thread[n_clients];
    	
    	clients[0] = new Task(task,0);
		for(int i = 1; i < clients.length; i++)
    		clients[i] = new Task((WebStoreTest) task.clone(), i);
    		
    	for(int i = 0; i < clients.length; i++) {
    		clients[i].start();
    	}
    		
		for(int i = 0; i < clients.length; i++)
			try {
					synchronized(clients[i]) {
						clients[i].join();
					}
			}
			catch(InterruptedException ex) {
				ex.printStackTrace();
			}
    }
    
    private class Task extends Thread {
    
    	WebStoreTest wst;
    	int id;
    
    	Task(WebStoreTest wst, int id) {
    		this.wst = wst;
    		this.id = id;
    	}
    	
    	public void run() {
    		wst.run();
    	}
    }
}

	