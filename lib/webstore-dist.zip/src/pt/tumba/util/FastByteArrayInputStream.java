package pt.tumba.util;

/*		 
 * MG4J: Managing Gigabytes for Java
 *
 * Copyright (C) 2003 Sebastiano Vigna 
 *
 *  This library is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU Lesser General Public License as published by the Free
 *  Software Foundation; either version 2.1 of the License, or (at your option)
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 *  for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */


/** Simple, fast and repositionable byte-array input stream.
 *
 * @author Sebastiano Vigna
 * @since 0.6
 */

public class FastByteArrayInputStream extends java.io.InputStream {

	/** The array backing the input stream. */
	public byte array[];

	/** The number of valid bytes in {@link #array} starting from {@link #offset}. */
	public int length;

	/** The current mark as a position, or -1 if no mark exists. */
	private int mark;

	/** The first valid entry. */
	public int offset;

	/** The current position as a distance from {@link #offset}. */
	private int position;

	/** Creates a new array input stream using a given array. 
	 *
	 * @param array the backing array.
	 */
	public FastByteArrayInputStream( final byte array[] ) {
		this( array, 0, array.length );
	}

	/** Creates a new array input stream using a given array fragment.
	 *
	 * @param array the backing array.
	 * @param offset the first valid entry of the array.
	 * @param length the number of valid bytes.
	 */
	public FastByteArrayInputStream( final byte array[], final int offset, final int length ) {
		this.array = array;
		this.offset = offset;
		this.length = length;
	}

	public int available() {
		return length - position;
	}

	/** Closing a fast byte array input stream has no effect. */
	public void close() {}

	public void mark( int dummy ) {
		mark = position;
	}

	public boolean markSupported() {
		return true;
	}

	public long position() {
		return position;
	}

	public void position( long newPosition ) {
		position = (int)Math.min( newPosition, length );
	}

	public int read() {
		if ( length == position ) return -1;
		return array[ position++ ] & 0xFF;
	}

	public int read( byte b[], int offset, int length ) {
		if ( this.length == this.position ) return -1;
		final int n = Math.min( length, this.length - this.position );
		System.arraycopy( array, this.offset + this.position, b, offset, n );
		this.position += n;
		return n;
	}

	public void reset() {
		position = mark;
	}

	public long skip( long n2) {
		long n = n2;
		if ( n <= length - position ) {
			position += (int)n;
			return n;
		}
		n = length - position;
		position = length;
		return n;
	}
}


// Local Variables:
// mode: jde
// tab-width: 4
// End:
