/*
 * Created on 27/Out/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package pt.tumba.util;

/**
 *  Description of the Class
 *
 *@author     bmartins
 *@created    22 de Agosto de 2002
 */
public class Timer {

    private long measured_time;
    private long start_time;
    private boolean started;


    /**
     *  Constructor for the Timer object
     */
    public Timer() {
        measured_time = 0;
        started = false;
    }


    /**
     *  Gets the started attribute of the Timer object
     *
     *@return    The started value
     */
    public boolean isStarted() {
        return started;
    }


    /**
     *  Description of the Method
     */
    public void reset() {
        measured_time = 0;
        if (started) {
            start_time = System.currentTimeMillis();
        }
    }


    /**
     *  Description of the Method
     */
    public void start() {
        if (started) {
            return;
        }
        started = true;
        start_time = System.currentTimeMillis();
    }


    /**
     *  Description of the Method
     */
    public void stop() {
        if (!started) {
            return;
        }
        long stop_time = System.currentTimeMillis();
        started = false;
        measured_time += stop_time - start_time;
    }


    /**
     *  Description of the Method
     *
     *@return    Description of the Return Value
     */
    public long time() {
        if (started) {
            long current_time = System.currentTimeMillis();
            return measured_time + (current_time - start_time);
        } else {
            return measured_time;
        }
    }


    /**
     *  Description of the Method
     *
     *@return    Description of the Return Value
     */
    public String toString() {
        return "Time measured so far: " + time() + " (ms)";
    }

}
