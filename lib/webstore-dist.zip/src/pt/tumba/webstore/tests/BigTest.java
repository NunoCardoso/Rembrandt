package pt.tumba.webstore.tests;

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Vector;

class BigTest {

	public static class RandomComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			double random = Math.random();
			return random < 0.5 ? -1 : 1;
		}
	}

	static void all_recursive(File root,Vector ret) {
		File[] f = root.listFiles();
		
		for(int i = 0; i < f.length; i++)
			if(f[i].isDirectory())
				all_recursive(f[i],ret);
			else
				ret.addElement(f[i]);
	}


	static class Keys implements java.io.Serializable {
		public pt.tumba.webstore.Key[] keys;
	}

	public static void main(String args[]) {
		
		try {
			
			int n_clients = Integer.valueOf(args[0]).intValue();
			int client = Integer.valueOf(args[1]).intValue();
			
			Vector allfiles = new Vector();
			
			all_recursive(new File(args[2]),allfiles);
			
			
			Vector list = new Vector();
			
			boolean split = args.length == 4 && args[3].equals("-s");
			
			for(int i = 0; i < allfiles.size(); i++)
				if(split) {
					if(i % n_clients == client)
						list.add(allfiles.elementAt(i));
				}
				else {
					list.add(allfiles.elementAt(i));
				}
			
			File[] files = new File[list.size()];
				
			for(int i = 0; i < files.length; i++)
				files[i] = (File) list.get(i);	
			
			
			// ---------------------------------------
	
			// randomizar
			Arrays.sort(files,new RandomComparator());

			
			WebStoreTest wst1 = new WebStoreTest("testStore",files,"/home/als/conf/webstore_conf.xml","logs/client" + client + ".log");
			
			
			
			//FileOutputStream fos = new FileOutputStream("logs" + File.separatorChar + client + ".test");
			//PrintWriter pw = new PrintWriter(fos);
			
			//pw.print("TestStore: " + files.length + " files.\n");
			
			System.out.println("client " + client + ": Store... " + files.length + " files.");
			
			long time = System.currentTimeMillis();
	
			
			java.io.FileInputStream fis = new java.io.FileInputStream("KEYS.DAT." + client);
			java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
			
			Keys k = (Keys) ois.readObject(); 

			wst1.keys = k.keys;
			
			
			wst1.testDelete();
			//wst1.testStore(client % 4);
			
			long time_store = System.currentTimeMillis() - time;
			
			/*
			Keys k = new Keys();
			k.keys = wst1.keys;
			
			java.io.FileOutputStream fos = new java.io.FileOutputStream("KEYS.DAT." + client);
			java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(fos);
			
			oos.writeObject(k);
			oos.close();
			fos.close();
			*/
			/*
			time = System.currentTimeMillis();
			System.out.println("client " + client + ": Retrieve...");
			try {
				wst1.testRetrieveNoCompare();
			}
			catch(Exception ex) {
				ex.printStackTrace();
				System.exit(1);
			}
			long time_retrieve = System.currentTimeMillis() - time;
			
			
			
			System.out.println("client " + client + ": Delete...");
			time = System.currentTimeMillis();
			wst1.testDelete();
			long time_delete = System.currentTimeMillis() - time;
			*/
				
			System.out.println("client " + client + ": End??");
			
			/*
			pw.write("TestStore = " + time_store / 1000 + " seconds. (" + time_store + ")\n");
			pw.write("TestRetrieve = " + time_retrieve / 1000 + " seconds. (" + time_retrieve + ")\n");
			pw.write("TestDelete = " + time_delete / 1000 + " seconds. (" + time_delete + ")\n");
			pw.write("TestTotal = " + (time_store + time_retrieve + time_delete) / 1000 + " seconds.\n");
			*/
			//pw.close();
			//fos.close();
		}
		catch(Exception ex) {
			ex.printStackTrace();
			System.exit(1);
		}
		return;
	}
}