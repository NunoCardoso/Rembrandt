package pt.tumba.webstore.volumeserver;

import java.io.File;

import pt.tumba.webstore.common.Compressor;
import pt.tumba.webstore.common.Header;


public class StoreRequest extends Request {

	byte[] data;
	
	int content_length;
	
	Header header;
	
	Compressor compressor;
	
	int storemode;
	
	public StoreRequest(File file, byte[] data, int content_length, Header header, Compressor compressor, int storemode) {
		super(file);
		this.data = data;
		this.content_length = content_length;
		this.header = header;
		this.compressor = compressor;
		this.storemode = storemode;
	}
	
	public String toString() {
		return  file.toString();			
	}
}
