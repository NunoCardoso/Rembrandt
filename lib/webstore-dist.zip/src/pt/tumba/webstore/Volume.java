package pt.tumba.webstore;

import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetSocketAddress;
import java.net.Socket;

import pt.tumba.webstore.common.Compressor;
import pt.tumba.webstore.common.Header;
import pt.tumba.webstore.exceptions.ContentNotFound;
import pt.tumba.webstore.exceptions.VolumeUnreachable;
import pt.tumba.webstore.volumeserver.CompressedContent;
import pt.tumba.webstore.volumeserver.DeleteRequest;
import pt.tumba.webstore.volumeserver.ExistsRequest;
import pt.tumba.webstore.volumeserver.FileAccess;
import pt.tumba.webstore.volumeserver.NotFound;
import pt.tumba.webstore.volumeserver.OK;
import pt.tumba.webstore.volumeserver.OKNotFirst;
import pt.tumba.webstore.volumeserver.RemoteError;
import pt.tumba.webstore.volumeserver.RetrieveRequest;
import pt.tumba.webstore.volumeserver.StoreRequest;



/**
 * Class that represents a WebStore volume with access via daemon.
 *  
 * @author Andre Santos, XLDB
 */
public class Volume implements Serializable {
	
	// volume id - root directory
	protected String vol_id;

	// webstore directory tree depth
	protected int depth;
    
	// is this volume writable?
	private boolean writable;

	// file access instance
	protected FileAccess fileaccess;
	
	// logfile
	protected File logfile;
	
	// dameon server
	InetSocketAddress server;
	
	// maximum number of runing threads in the server
	int maxthreads;
	
	/**
	 * Creates a new Volume (access via VolumeServer).
	 * 
	 * @param vol_id Volume ID - corresponds to the volume's root directory.
	 * @param depth Volume depth.
	 * @param writable Is it writable?
	 * @param server Volume server host.
	 * @param logfile Logfile.
	 */
	public Volume(String vol_id,int depth,boolean writable,InetSocketAddress server,File logfile,int maxthreads) {
		this.vol_id = vol_id;
		this.depth = depth;
		this.writable = writable;
		this.server = server;
		this.logfile = logfile;
		this.maxthreads = maxthreads;
	}	
	
	/**
	 * Volume ID.
	 * @return The volume's ID.
	 */
	public String volId() {
		return vol_id;
	}
	
	/**
	 * Volume location.
	 * @return Volume's host.
	 */
	public InetSocketAddress host() {
		return server;
	}
	
	/**
	 * Logfile.
	 * @return Volume's logfile path.
	 */
	public File logFile() {
		return logfile;
	}
	
	/**
	 * Maximum number of threads running on the server.
	 * 
	 * @return Maximum number of threads running on the server.
	 */
	public int maxThreads() {
		return maxthreads;
	}
	
	/**
	 * Is the volume full?
	 * @return <i>true</i> if it's full, <i>false</i> otherwise.
	 */
   	public boolean isFull() {
   		return !writable;
	}

	/**
	 * Returns the volume's depth.
	 * @return An integer representing the volume's depth.
	 */
   	int getDepth() {
	   return depth;
   	}

	/**
	 * Returns a string representation of the volume.
	 * @return A string that is the volume's id (the same as the volume's root dir).
	 */
	public String toString() {
		return vol_id;
	}
	   
	/**
	 * Stores a content with a specified type of compression.
	 *
	 * @param content Content to store.
	 * @param compressor Compressor that will compress the content.
	 * @param storemode WebStore policy for the store operation.
	 *
	 * @return A key that will allow the access to this content.
	 */
	protected Key put(Content content, Compressor compressor, int storemode)
	throws VolumeUnreachable {
			
		long sig = content.getSignature();
		File file = new File(vol_id + File.separatorChar + Content.getLocation(new Key(null,sig,false),depth));
					 
        Object server_response = null;
        		
		byte[] data = compressor.deflate(content.getData());
				
		try {
			Socket socket = new Socket(server.getAddress(),server.getPort());
			
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
			
			Header h = new Header("1",compressor.toString(),content.getData().length,1);
			out.writeObject(new StoreRequest(file,data,content.getData().length,h,compressor,storemode));
			out.flush();

			while(server_response == null)
				server_response = in.readObject();
			
			in.close();
			out.close();
			socket.close();
		}
		catch(Exception ex) {
			throw new VolumeUnreachable("volume '" + vol_id + "': " + ex.getMessage());
		}

		Key ret = null;
		
		if(server_response instanceof RemoteError) {
			ret = null;
		}
		else if(server_response instanceof OK)
			ret = new Key(vol_id,sig,!(server_response instanceof OKNotFirst));
		else {
			 ret = (Key) server_response;
		}       
		
		return ret;
	}
	
	
	/**
	 * Retrieves a content, given its key.
	 *
	 * @param key Content's key.
	 *
	 * @return The content corresponding to the given key.
	 *
	 * @throws ContentNotFound When the content corresponding to the given key wasn't found.
	 */
	protected CompressedContent get(Key key)
	throws ContentNotFound, VolumeUnreachable {
		File file = new File(vol_id + File.separatorChar + Content.getLocation(key,depth));
		
		Object server_response = null;
		
		try { 
			Socket socket = new Socket(server.getAddress(),server.getPort());

			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());

			out.writeObject(new RetrieveRequest(file));
			out.flush();
			
			while(server_response == null)
				server_response = in.readObject();
			
			in.close();
			out.close();
			socket.close();
		}
		catch(Exception ex) {
				throw new VolumeUnreachable("volume '" + vol_id + "': " + ex.getMessage());
		}
		
		if(server_response instanceof NotFound)
			throw new ContentNotFound(key,file);
					
		return (CompressedContent) server_response;
	}
	
	/**
	 * Deletes a content, given its key.
	 *
	 * @param key Content's key.
	 *
	 * @throws ContentNotFound When the content corresponding to the given key wasn't found.
	 */
	protected void delete(Key key)
		throws ContentNotFound, VolumeUnreachable {
			File file = new File(vol_id + File.separatorChar + Content.getLocation(key,depth));
		
			Object server_response = null;
		
			try { 
				Socket socket = new Socket(server.getAddress(),server.getPort());
	
				ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
				ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
	
				out.writeObject(new DeleteRequest(file));
				out.flush();

				while(server_response == null)
					server_response = in.readObject();
				
				in.close();
				out.close();
				socket.close();
			}
			catch(Exception ex) {
					throw new VolumeUnreachable("volume '" + vol_id + "': " + ex.getMessage());
			}
		
			if(server_response instanceof NotFound)
				throw new ContentNotFound(key,file);
		}
		
		
	/**
	 * Does the content exists?
	 * In case of using the regular store policy, the content is imediatly stored.
	 * 
	 * @param content Content to search for.
	 * @param regularStore Regular Store policy?
	 * @param compressor Compressor to use, if case.
	 * 
	 * @return a Key if exists (and the content was stored), null otherwise.
	 */
	Key exists(Content content, int POLICY, Compressor compressor) throws VolumeUnreachable {
		Object server_response = null;
		Object server_response2 = null;
	
		long sig = content.getSignature();
		long contentlength = content.getData().length;
		File file = new File(vol_id + File.separatorChar + Content.getLocation(new Key(null,sig,false),depth));
	
		try {
			Socket socket = new Socket(server.getAddress(),server.getPort());
		
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
		
			out.writeObject(new ExistsRequest(file,contentlength,POLICY));
			out.flush();

			while(server_response == null)
				server_response = in.readObject();
		
			/* if exists */
			if(server_response instanceof OK) {
				/* in case of a Regular Store, the content doesn't need to be sent */ 
				if(POLICY == WebStore.REGULAR_STORE_POLICY) {
					server_response2 = server_response;	
				}
				else {
					byte[] data = compressor.deflate(content.getData());
					Header h = new Header("1",compressor.toString(),content.getData().length,1);
					out.writeObject(new StoreRequest(file,data,(int) contentlength,h,compressor,POLICY));
					out.flush();
				
					while(server_response2 == null)
						server_response2 = in.readObject();
				}				
			}
		
			in.close();
			out.close();
			socket.close();
		}
		catch(Exception ex) {
			throw new VolumeUnreachable("volume '" + vol_id + "': " + ex.getMessage());
		}
		
		Key ret = null;
		if(server_response2 instanceof OK || server_response2 instanceof OKNotFirst)
			ret = new Key(vol_id,sig,!(server_response2 instanceof OKNotFirst));
		else 
			if(server_response2 instanceof Key)
				ret = (Key) server_response2;
				
		return ret;
	}
}

