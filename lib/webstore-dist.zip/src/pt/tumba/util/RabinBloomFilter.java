/*
 * Created on 14/Out/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package pt.tumba.util;

/**
 * @author bmartins
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RabinBloomFilter {
	
		private RabinHashFunction64 hashfunction = new RabinHashFunction64();
	
		private boolean keys[];

		private int numFunctions;
	
	public RabinBloomFilter(String filter ) {
		int index1 = filter.indexOf(":");
		int index2 = filter.lastIndexOf(":");
		numFunctions = new Integer(filter.substring(0,index1)).intValue();
		keys = new boolean[new Integer(filter.substring(index1,index2)).intValue()];
		for (int i =index2+1; i<filter.length(); i++) 
		if(filter.charAt(i)=='1') keys[i] = true; else keys[i] = false;
	}

	
		/**
		 *  Constructor for the BloomFilter object
		 *
		 *@param  numKeys  Description of the Parameter
		 */
		public RabinBloomFilter(int numKeys) {
			this(numKeys, 10);
		}
	
		/**
		 *  Constructor for the BloomFilter object
		 *
		 *@param  numKeys           Description of the Parameter
		 *@param  numHashFunctions  Description of the Parameter
		 */
		public RabinBloomFilter(int numKeys, int numHashFunctions) {
			this.keys = new boolean[numKeys];
			this.numFunctions = numHashFunctions;
			for (int i = 0; i < numKeys; i++) {
				this.keys[i] = false;
			}
		}

    /**
     *  Gets the hash attribute of the BloomFilter object
     *
     *@param  fnum      Description of the Parameter
     *@param  original  Description of the Parameter
     *@return           The hash value
     */
    private int getHash(int fnum, long original) {
		return (int)((long)(Math.pow(2,fnum)) * original) % (keys.length);
    }
	
	
		/**
		 *  Gets the present attribute of the BloomFilter object
		 *
		 *@param  obj  Description of the Parameter
         *@return      The present value
         */
    public boolean hasKey(Object obj) throws Exception {
        boolean result = true;
        long hashCodeObject = Math.abs(hashfunction.hash(obj));
        for (int i = 0; i < numFunctions && result; i++) {
            result &= keys[getHash(i, hashCodeObject)];
        }
        return result;
    }
	
	
		/**
		 *  Description of the Method
		 *
		 *@param  obj  Description of the Parameter
		 */
		public void put(Object obj) throws Exception {
			long hashCodeObject = Math.abs(hashfunction.hash(obj));
			for (int i = 0; i < numFunctions; i++) {
				keys[getHash(i, hashCodeObject)] = true;
			}
		}

	public String toString() {
		String aux =  numFunctions + ":" + keys.length + ":";
		for (int i=0; i<keys.length; i++ ) {
			if(keys[i]) aux += "1"; else aux+="0";
		}
		return aux;
	}

}
