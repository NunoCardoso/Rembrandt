package pt.tumba.util;

/** Simple, fast byte-array output stream that exposes the backing array.
 *
 * <P>{@link java.io.ByteArrayOutputStream} is nice, but to get its content you
 * must generate each time a new object. This doesn't happen here.
 *
 * <P>This class will automatically enlarge the backing array, doubling its
 * size whenever new space is needed. The {@link #reset()} method will
 * mark the content as empty, but will not decrease the capacity: use 
 * {@link #trim()} for that purpose.
 *
 * @author Sebastiano Vigna
 * @since 0.6
 */

public class FastByteArrayOutputStream extends java.io.OutputStream {

	/** The array backing the output stream. */
	public final static int DEFAULT_INITIAL_CAPACITY = 16;

	/** The array backing the output stream. */
	public byte array[];

	/** The number of valid bytes in {@link #array}. */
	public int length;


	/** Creates a new array output stream with an initial capacity of {@link #DEFAULT_INITIAL_CAPACITY} bytes. */
	public FastByteArrayOutputStream() {
		this( DEFAULT_INITIAL_CAPACITY );
	}

	/** Creates a new array output stream wrapping a given byte array.
	 *
	 * @param a the byte array to wrap.
	 */
	public FastByteArrayOutputStream( byte a[] ) {
		array = a;
	}

	/** Creates a new array output stream with a given initial capacity.
	 *
	 * @param initialCapacity the initial length of the backing array.
	 */
	public FastByteArrayOutputStream( int initialCapacity ) {
		array = new byte[ initialCapacity ];
	}

	/** Marks this array output stream as empty. */
	public void reset() {
		length = 0;
	}

	/** Ensures that the length of the backing array is equal to {@link #length}. */
	public void trim() {
		byte array2[] = new byte[length];
		for(int i=0; i<array.length; i++) array2[i] = array[i];
		array = array2;
	}

	public void write( int b ) {
		if ( length == array.length ) {
			byte array2[] = new byte[Math.max( length, 1 ) * 2];
			for(int i=0; i<array.length; i++) array2[i] = array[i];
			array = array2;
		}
		array[ length ++ ] = (byte)b;
	}
}


// Local Variables:
// mode: jde
// tab-width: 4
// End:
