package pt.tumba.util;

import java.io.IOException;
import java.io.Reader;

/** Lightweight, unsynchronised, aligned reader buffering class.
 *
 * <P>This class provides buffering for readers, but it does so with 
 * purposes and an internal logic that are radically different from the ones
 * adopted in {@link java.io.BufferedReader}.
 * 
 * <P>There is no support for marking. All methods are unsychronised. Moreover,
 * it is guaranteed that <em>all reads performed by this class will be
 * multiples of the given buffer size</em>.  If, for instance, you use the
 * default buffer size, reads will be performed on the underlying input stream
 * in multiples of 16384 bytes. This is very important on operating systems
 * that optimise disk reads on disk block boundaries.
 * 
 */

public class FastBufferedReader extends Reader {

	/** The default size of the internal buffer in bytes (16Ki). */
	public final static int DEFAULT_BUFFER_SIZE = 16 * 1024;

	/** The number of buffer bytes available starting from {@link #pos}. */
	protected int avail;

	/** The internal buffer. */
	protected char buffer[];

	/** The current position in the buffer. */
	protected int pos;

	/** The underlying reader. */
	protected Reader r;

	/** Creates a new fast buffered reader by wrapping a given reader with a buffer of {@link #DEFAULT_BUFFER_SIZE} characters. 
	 *
	 * @param r a reader to wrap.
	 */
	public FastBufferedReader( final Reader r ) {
		this( r, DEFAULT_BUFFER_SIZE );
	}

	/** Creates a new fast buffered reder by wrapping a given reder with a given buffer size. 
	 *
	 * @param r a reader to wrap.
	 * @param bufSize the size in bytes of the internal buffer.
	 */

	public FastBufferedReader( final Reader r, final int bufSize ) {
		this.r = r;
		buffer = new char[ bufSize ];
	}


	public void close() throws IOException {
		if ( r == null ) return;
		r.close();
		r = null;
		buffer = null;
	}

	public int read() throws IOException {
		if ( avail == 0 ) {
			avail = r.read( buffer );
			if ( avail <= 0 ) {
				avail = 0;
				return -1;
			}
			pos = 0;
		}
		avail--;
		return buffer[ pos++ ] & 0xFFFF;
	}


	public int read( final char b[], int offset2, int length2 ) throws IOException {
		int offset = offset2;
		int length = length2;
		if ( length <= avail ) {
			System.arraycopy( buffer, pos, b, offset, length );
			pos += length;
			avail -= length;
			return length;
		}
	
		final int head = avail;
		System.arraycopy( buffer, pos, b, offset, head );
		offset += head;
		length -= head;
		avail = 0;

		final int residual = length % buffer.length;
		int result;

		if ( ( result = r.read( b, offset, length - residual ) ) < length - residual ) 
			return result < 0 
				? ( head != 0 ? head : -1 ) 
				: result + head;

		avail = r.read( buffer );
		if ( avail < 0 ) {
			avail = 0;
			return result + head > 0 ? result + head : -1;
		}
		pos = Math.min( avail, residual );
		System.arraycopy( buffer, 0, b, offset + length - residual, pos );
		avail -= pos;
		return result + head + pos;
	}

	/** Reads a line into the given mutable string.
	 *
	 * <P>The next line of input (defined as in {@link java.io.BufferedReader#readLine()})
	 * will be stored into <code>s</code>. Note that if <code>s</code> is not {@linkplain it.unimi.dsi.mg4j.util.MutableString loose}
	 * this method will be quite inefficient.
	 *
	 * @param s a mutable string.
	 * @return <code>s</code> or <code>null</code> if the end of file was found.
	 */

	public MutableString readLine( MutableString s ) throws IOException {
		char c = 0;
		int i;

		if ( avail == 0 ) {
			avail = r.read( buffer );
			if ( avail <= 0 ) {
				avail = 0;
				return null;
			}
			pos = 0;
		}

		s.length( 0 );
		for(;;) {
			for( i = 0; i < avail && ( c = buffer[ pos + i ] ) != '\n' && c != '\r' ; i++ );

			s.append( buffer, pos, i  );
			pos += i; 
			avail -= i;

			if ( avail > 0 ) {
				if ( c == '\n' ) { // LF only.
					pos++;
					avail--;
				}
				else { // c == '\r'
					if ( avail > 1 ) {
						if ( buffer[ pos + 1 ] == '\n' ) { // CR/LF with LF already in the buffer.
							pos += 2;
							avail -= 2;
						}
						else { // CR only with following character already in the buffer.
							pos++;
							avail--;
						}
					}
					else { // We must search for the LF.
						pos = 0;
						avail = r.read( buffer );
						if ( avail <=  0 ) avail = 0;
						else if ( buffer[ 0 ] == '\n' ) {
							pos++;
							avail--;
						}
					}
				}
				return s;
			}
			else {
				pos = 0;
				avail = r.read( buffer );
				if ( avail <=  0 ) {
					avail = 0;
					return s;
				}
			}
		}
	}

	public long skip( long n2 ) throws IOException {
		long n = n2;
		if ( n <= avail ) {
			final int m = (int)n;
			pos += m;
			avail -= m;
			return n;
		}

		final int head = avail;
		n -= head;
		avail = 0;

		final int residual = (int)( n % buffer.length );
		long result;
		if ( ( result = r.skip( n - residual ) ) < n - residual ) {
			avail = 0;
			return result + head;
		}

		avail = Math.max( r.read( buffer ), 0 );
		pos = Math.min( residual, avail );
		avail -= pos;
		return result + head + pos;
	}

}
	

// Local Variables:
// mode: jde
// tab-width: 4
// End:
