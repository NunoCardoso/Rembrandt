/**
 * NoCompression.java
 *
 * @author André� Santos, XLDB
 */

package pt.tumba.webstore.common;



public class NoCompression extends Compressor {

    /**
     * Doesn't do anything, just returns the same data (silly).
     *
     * @param data Data.
     *
     * @return The same data.
     */
    public byte[] deflate(byte[] data) {
        return data;
    }

    /**
     * Doesn't do anything, just returns the same data (silly).
     *
     * @param data Data.
     *
     * @return The same data.
     */
    public byte[] inflate(byte[] data) {
        return data;
    }

    /**
     * Returns the string representation of the compressor.
     */
    public String toString() {
        return "No compression";
    }
}