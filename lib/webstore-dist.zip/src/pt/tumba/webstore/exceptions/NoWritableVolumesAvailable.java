package pt.tumba.webstore.exceptions;



/**
 * Thrown when there are no writable volumes to store a content.
 * This can happen when the user performs the <i>put</i> operation without specifying the volume where to store. 
 * 
 * @author Andre Santos, XLDB
 */
public class NoWritableVolumesAvailable extends Exception {

	public NoWritableVolumesAvailable() {
		super("There are no writable volumes available for storing contents.");
	}
}
