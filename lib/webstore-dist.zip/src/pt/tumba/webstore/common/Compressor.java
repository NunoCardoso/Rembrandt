/**
 * Compressor.java
 *
 * @author Andr? Santos, XLDB
 */

package pt.tumba.webstore.common;

import java.io.Serializable;

import pt.tumba.webstore.exceptions.DecompressionError;



public abstract class Compressor implements Serializable {
    
    /**
     * Compresses data.
     *
     * @param data Non-compressed data to compress.
     *
     * @return Compressed data.
     */
    public abstract byte[] deflate(byte[] data);
    
    /**
     * Uncompresses data.
     *
     * @param data Compressed data to decompress.
     *
     * @return non-compressed data.
     */    
    public abstract byte[] inflate(byte[] data) throws DecompressionError;

    /**
     * Returns the string representation of the compressor.
     *
     * @return A string that is the compressor name.
     */
    public abstract String toString();
}
