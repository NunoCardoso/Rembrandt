/*
 * Created on 9/Dez/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package pt.tumba.util;

/**
 * A <code>PredicatedIterator</code> enumerates only those elements of a collection
 * that match the supplied <code>Predicate</code>.
 * 
 * @author Jez Higgins, jez@jezuk.co.uk
 * @version $Id: PredicatedIterator.java,v 1.1 2003/12/09 17:45:28 bmartins Exp $
 */
public abstract class PredicatedIterator implements java.util.Iterator
{

  public abstract boolean predicateTest ( Object o ); 

  public PredicatedIterator(java.util.Iterator iterator)
  {
    iter_ = iterator;
	next_ = null;
	firstTime = true;
  } // PredicatedIterator

  public boolean hasNext() {
    if(firstTime) {
    	findNext();
    	firstTime = false;
    }
    return (next_ != null);
  } // hasNext

  public Object next()
  {
	if(firstTime) {
		findNext();
		firstTime = false;
	}
    Object current = next_;
    findNext();
    return current;
  } // next

  public void remove()
  {
    throw new UnsupportedOperationException("this Iterator does not support the remove method");
  } // remove

  private void findNext()
  {
    next_ = null;
    while(iter_.hasNext() && next_ == null)
    {
      Object candidate = iter_.next();
      if(predicateTest(candidate))
        next_ = candidate;
    } // while
  } // findNext

  ////////////////////////
  private java.util.Iterator iter_;
  private Object next_;
  private boolean firstTime;
} // PredicatedIterator
