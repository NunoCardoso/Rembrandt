package pt.tumba.webstore.volumeserver;


public class OK extends ServerReply {

}
