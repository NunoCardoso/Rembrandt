package pt.tumba.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/**
 *  <p>
 *
 *  This class provides an implementation of a hash function based on Rabin
 *  fingerprints, which can efficiently produce a 32-bit hash value for a
 *  sequence of bytes. It does so by considering strings of bytes as large
 *  polynomials with coefficients of 0 and 1 and then reducing them modulo some
 *  irreducible polynomial of degree 32. The result is a hash function with very
 *  satisfactory properties. In addition the polynomial operations are fast in
 *  hardware; even in this Java implementation the speed is reasonable.</p> <p>
 *
 *  The implementation is derived from the paper "Some applications of Rabin's
 *  fingerprinting method" by Andrei Broder. See <a
 *  href="http://server3.pa-x.dec.com/SRC/publications/src-papers.html">
 *  http://server3.pa-x.dec.com/SRC/publications/src-papers.html</a> for a full
 *  citation and the paper in PDF format.</p> <p>
 *
 *  Included in this class are additional methods that can compute a hash value
 *  for any serializable object, string, file, or resource denoted by URL.</p>
 *
 *@author     Sean Owen (srowen@yahoo.com)
 *@created    22 de Agosto de 2002
 *@version    1.1
 */
public final class RabinHashFunction implements Serializable {

	public final static int DEFAULT_IRREDUCIBLE_POLY = 0x000001C7;
	private final static Map functions =
		Collections.synchronizedMap(new WeakHashMap());

	private final static int P_DEGREE = 32;
	private final static int READ_BUFFER_SIZE = 2048;
	private final static int X_P_DEGREE = 1 << (P_DEGREE - 1);

	private final static RabinHashFunction DEFAULT_HASH_FUNCTION =
		new RabinHashFunction(DEFAULT_IRREDUCIBLE_POLY);

	static {
		functions.put(
			new Integer(DEFAULT_IRREDUCIBLE_POLY),
			DEFAULT_HASH_FUNCTION);
	}


	/**
	 *  Retrieves the RabinHashFunction using the default polynomial.
	 *
	 *@return    default RabinHashFunction
	 */
	public static RabinHashFunction getDefaultHashFunction() {
		return DEFAULT_HASH_FUNCTION;
	}

	/**
	 *  <p>
	 *
	 *  Retrieves a RabinHashFunction using the specified polynomial,
	 *  represented as an <code>int</code>.</p> <p>
	 *
	 *  The 32 bits of the integer represent the coefficients of the degree 32
	 *  polynomial over GF(2); that is, every coefficient is 0 or 1. However, a
	 *  degree 32 polynomial has 33 coefficients; the term of degree 32 is
	 *  assumed to have a coefficient of 1. Therefore, the high-order bit of the
	 *  <code>int</code> is the degree 31 term's coefficient, and the low-order
	 *  bit is the constant coefficient.</p> <p>
	 *
	 *  For example the integer 0x00000803, in binary, is:</p> <p>
	 *
	 *  <code>00000000 00000000 00001000 00000011</code></p> <p>
	 *
	 *  Therefore it correponds to the polynomial:</p> <p>
	 *
	 *  <code>x<sup>32</sup> + x<sup>11</sup> + x + 1</code></p> <p>
	 *
	 *  This class does not test the polynomial for irreducibility; therefore
	 *  this constructor should only be used with polynomials that are already
	 *  known to be irreducible, or else results will be unreliable.</p>
	 *
	 *@param  irreduciblePolynomial  Description of the Parameter
	 *@return                        The hashFunction value
	 */
	public static RabinHashFunction getHashFunction(int irreduciblePolynomial) {
		Integer key = new Integer(irreduciblePolynomial);
		RabinHashFunction function = (RabinHashFunction) functions.get(key);
		if (function == null) {
			function = new RabinHashFunction(irreduciblePolynomial);
			functions.put(key, function);
		}
		return function;
	}
	private final byte[] buffer;
	private final int P;

	private final int[] table32, table40, table48, table54;

	/**
	 *  Constructor for the RabinHashFunction object
	 *
	 *@param  P  Description of the Parameter
	 */
	private RabinHashFunction(int P) {
		this.P = P;
		table32 = new int[256];
		table40 = new int[256];
		table48 = new int[256];
		table54 = new int[256];
		buffer = new byte[READ_BUFFER_SIZE];

		// We want to have mods[i] == x^(P_DEGREE+i)
		int[] mods = new int[P_DEGREE];
		mods[0] = P;
		for (int i = 1; i < P_DEGREE; i++) {
			// x^i == x(x^(i-1)) (mod P)
			mods[i] = mods[i - 1] << 1;
			// if x^(i-1) had a x_(P_DEGREE-1) term then x^i has a
			// x^P_DEGREE term that 'fell off' the top end.
			// Since x^P_DEGREE == P (mod P), we should add P
			// to account for this:
			if ((mods[i - 1] & X_P_DEGREE) != 0) {
				mods[i] ^= P;
			}
		}
		for (int i = 0; i < 256; i++) {
			int c = i;
			for (int j = 0; j < 8 && c != 0; j++) {
				if ((c & 1) != 0) {
					table32[i] ^= mods[j];
					table40[i] ^= mods[j + 8];
					table48[i] ^= mods[j + 16];
					table54[i] ^= mods[j + 24];
				}
				c >>>= 1;
			}
		}
		mods = null;
	}

	/**
	 *  Return the Rabin hash value of an array of bytes.
	 *
	 *@param  A  the array of bytes
	 *@return    the hash value
	 */
	public int hash(byte[] A) {
		return hash(A, 0, A.length, 0);
	}

	/**
	 *  Description of the Method
	 *
	 *@param  A       Description of the Parameter
	 *@param  offset  Description of the Parameter
	 *@param  length  Description of the Parameter
	 *@param  w       Description of the Parameter
	 *@return         Description of the Return Value
	 */
	private int hash(byte[] A, int offset, int length, int ws) {
		int w = ws;
		int start = length % 4;
		for (int s = offset; s < offset + start; s++) {
			w = (w << 8) ^ (A[s] & 0xFF);
		}
		for (int s = start + offset; s < length + offset; s += 4) {
			w =
				table32[w
					& 0xFF]
					^ table40[(w >>> 8)
					& 0xFF]
					^ table48[(w >>> 16)
					& 0xFF]
					^ table54[(w >>> 24)
					& 0xFF]
					^ (A[s] << 24)
					^ ((A[s + 1] & 0xFF) << 16)
					^ ((A[s + 2] & 0xFF) << 8)
					^ (A[s + 3] & 0xFF);
		}
		return w;
	}

	/**
	 *  Return the Rabin hash value of an array of chars.
	 *
	 *@param  A  the array of chars
	 *@return    the hash value
	 */
	public int hash(char[] A) {
		int w = 0;
		int start = 0;
		if (A.length % 2 == 1) {
			w = A[0] & 0xFFFF;
			start = 1;
		}
		for (int s = start; s < A.length; s += 2) {
			w =
				table32[w
					& 0xFF]
					^ table40[(w >>> 8)
					& 0xFF]
					^ table48[(w >>> 16)
					& 0xFF]
					^ table54[(w >>> 24)
					& 0xFF]
					^ ((A[s] & 0xFFFF) << 16)
					^ (A[s + 1] & 0xFFFF);
		}
		return w;
	}

	/**
	 *  Computes the Rabin hash value of the contents of a file.
	 *
	 *@param  f                       the file to be hashed
	 *@return                         the hash value of the file
	 *@throws  FileNotFoundException  if the file cannot be found
	 *@throws  IOException            if an error occurs while reading the file
	 */
	public int hash(File f) throws FileNotFoundException, IOException {
		FileInputStream fis = new FileInputStream(f);
		try {
			return hash(fis);
		} finally {
			fis.close();
		}
	}

	/**
	 *  Computes the Rabin hash value of the data from an <code>InputStream</code>
	 *  .
	 *
	 *@param  is            the InputStream to hash
	 *@return               the hash value of the data from the InputStream
	 *@throws  IOException  if an error occurs while reading from the
	 *      InputStream
	 */
	public int hash(InputStream is) throws IOException {
		int hashValue = 0;
		int bytesRead;
		synchronized (buffer) {
			while ((bytesRead = is.read(buffer)) > 0) {
				hashValue = hash(buffer, 0, bytesRead, hashValue);
			}
		}
		return hashValue;
	}

	/**
	 *  Returns the Rabin hash value of an array of integers. This method is the
	 *  most efficient of all the hash methods, so it should be used when
	 *  possible.
	 *
	 *@param  A  array of integers
	 *@return    the hash value
	 */
	public int hash(int[] A) {
		int w = 0;
		for (int s = 0; s < A.length; s++) {
			w =
				table32[w
					& 0xFF]
					^ table40[(w >>> 8)
					& 0xFF]
					^ table48[(w >>> 16)
					& 0xFF]
					^ table54[(w >>> 24)
					& 0xFF]
					^ A[s];
		}
		return w;
	}

	/**
	 *  Description of the Method
	 *
	 *@param  obj              Description of the Parameter
	 *@return                  Description of the Return Value
	 *@exception  IOException  Description of the Exception
	 */
	public int hash(Object obj) throws IOException {
		return hash((Serializable) obj);
	}

	/**
	 *  Returns the Rabin hash value of a serializable object.
	 *
	 *@param  obj           the object to be hashed
	 *@return               the hash value
	 *@throws  IOException  if serialization fails
	 */
	public int hash(Serializable obj) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
			oos.writeObject(obj);
			return hash(baos.toByteArray());
		} finally {
			oos.close();
			baos.close();
			oos = null;
			baos = null;
		}
	}

	/**
	 *  Computes the Rabin hash value of a String.
	 *
	 *@param  s  the string to be hashed
	 *@return    the hash value
	 */
	public int hash(String s) {
		return hash(s.toCharArray());
	}

	/**
	 *  Computes the Rabin hash value of the contents of a file, specified by
	 *  URL.
	 *
	 *@param  url           the URL of the file to be hashed
	 *@return               the hash value of the file
	 *@throws  IOException  if an error occurs while reading from the URL
	 */
	public int hash(URL url) throws IOException {
		InputStream is = url.openStream();
		try {
			return hash(is);
		} finally {
			is.close();
		}
	}
}
