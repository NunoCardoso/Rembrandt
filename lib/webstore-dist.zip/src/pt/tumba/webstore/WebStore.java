package pt.tumba.webstore;

import java.io.File;
import java.util.Vector;

import org.apache.log4j.Logger;

import pt.tumba.webstore.common.Compressor;
import pt.tumba.webstore.common.ConfigParser;
import pt.tumba.webstore.common.NoCompression;
import pt.tumba.webstore.common.ZLib;
import pt.tumba.webstore.exceptions.ContentNotFound;
import pt.tumba.webstore.exceptions.DecompressionError;
import pt.tumba.webstore.exceptions.InvalidConfigFile;
import pt.tumba.webstore.exceptions.InvalidKey;
import pt.tumba.webstore.exceptions.NoSuchCompressor;
import pt.tumba.webstore.exceptions.NoWritableVolumesAvailable;
import pt.tumba.webstore.exceptions.VolumeNotWritable;
import pt.tumba.webstore.exceptions.VolumeUnreachable;
import pt.tumba.webstore.volumeserver.CompressedContent;


/**
 * Represents a WebStore instance; <b>This is the main class for WebStore usage</b>.
 * 
 * @version v.1<br><br>
 * 
 * A WebStore instance is composed by one or more volumes.<br>
 * In order to use the library, there is the need to supply a configuration file (XML).<br><br>
 * 
 * The following example ilustrates the main features of this class:<br><br>
 * 
 * 
<pre>
import java.io.File;
import pt.tumba.webstore.*;

public class DemoWebStore {
    public static void main(String[] args) {
	try {
	    WebStore ws = new WebStore(new File("webstore-conf.xml"));

		String s1 = "bla bla bla";
		String s2 = "ble ble ble";
	    
	    Content original1 = new Content(s1.getBytes());
	    Content original2 = new Content(s2.getBytes());
	    
	    ws.setDefaultCompressMode(WebStore.ZLIB);

	    // store a content
	    Key key1 = ws.store(original1);
	    
	    Volume[] volumes = ws.getVolumes(WebStore.WRITABLE);
	    
	    // store a content in a specified volume
	    // [assuming that there is at least one writable volume] 
	    Key key2 = ws.store(original2,volumes[0]);
	    
	    // retrieve the same content with the given keys
	    Content content1 = ws.retrieve(key1);
	    Content content2 = ws.retrieve(key2);
	    
	    // content1.equals(original1) and content2.equals(original2) should return true
	    
	    // delete the contents with the given keys
	    ws.delete(key1);
	    ws.delete(key2);
	}
	catch(Exception ex) {
	    // different exceptions can occour here
	    System.out.println(ex.getMessage());
	}
    }
}
</pre>
 *
 * @see InvalidConfigFile  
 * @see VolumeNotWritable
 * @see VolumeUnreachable
 * @see NoWritableVolumesAvailable
 * @see ContentNotFound
 * @see DecompressionError
 * @see NoSuchCompressor
 * @see InvalidKey
 *
 * @author Andre Santos, XLDB
 */
public class WebStore {

	/**
	 * No compression.
	 */
	public static final int NO_COMP = 0;

   /**
    * ZLib compression algorithm.
 	*/
   	public static final int ZLIB = 1;

	/**
	 * <i>Force New Content</i> store policy.
	 */
	public static final int FORCE_NEW_POLICY = 1;

	/**
	 * <i>Compare Contents</i> store policy.
	 */
	public static final int COMPARE_CONTENTS_POLICY = 2;

	/**
	 * <i>Regular Store</i> story policy.
	 */
	public static final int REGULAR_STORE_POLICY = 0;

	/**
	 * Full Volume.
	 */
	public static final int FULL = 0;
	
	/**
	 * Writable Volume.
	 */
	public static final int WRITABLE = 1;
	
	/**
	 * On.
	 */
	public static final int ON = 0;
	
	/**
	 * Off.
	 */
	public static final int OFF = 1;
	

    // name
    private String name;

    // volumes
    private Volume[] volumes;

    // number of writable volumes
    private int writable_volumes_length;
    
    // compressors
    private Compressor[] compressors = {new NoCompression(),new ZLib()};

    // compressors id
    private int[] compressors_code = {NO_COMP,ZLIB};

    // logging is ON?
    private boolean logging_on;
    
	// logger
	static Logger logger;
    
    // default compression mode
    private int defaultCompressMode;
    
    // default semantic
    private int defaultDuplicatesPolicy;
    
    
    /**
     * Creates a new WebStore instance, from a configuration file in XML.
     *
     * @param config configuration file in XML.
     */
    public WebStore(File config) throws InvalidConfigFile {
        ConfigParser cp = new ConfigParser();
        cp.parse(config);

        name = cp.name;
        volumes = cp.getVolumes();
        
        writable_volumes_length = 0;
        for(int i = 0; i < volumes.length; i++)
            if(!volumes[i].isFull())
                writable_volumes_length++;
    	
    	// defaults
    	defaultCompressMode = ZLIB;
    	defaultDuplicatesPolicy = REGULAR_STORE_POLICY;
    	logging_on = false;
    }

	/**
	 * Sets the default compression mode for <i>store</i> operation.
	 * By default, the compress mode is WebStore.ZLIB.
	 * 
	 * @param COMPRESS_MODE WebStore.NO_COMP for no compression, or WebStore.ZLIB for ZLib.
	 */
	public void setDefaultCompressMode(int COMPRESS_MODE) {
		defaultCompressMode = COMPRESS_MODE; // TODO: verificar se existe o compressor
	}

	/**
	 * Sets the default duplicates management policy for the <i>store</i> operation. 
	 * By default, the default policy is WebStore.REGULAR_STORE_POLICY.
	 * 
	 * @param POLICY WebStore.REGULAR_STORE_POLICY, WebStore.FORCE_NEW_POLICY or WebStore.COMPARE_CONTENTS_POLICY.
	 */	
	public void setDefaultDuplicatesPolicy(int POLICY) {
		defaultDuplicatesPolicy = POLICY;
	}

    /**
     * Stores a content. The WebStore will decide in which volume the content will be stored.
     *
     * @param content Content to store.
     *
     * @return A key that makes possible the access to the stored content later.
     *
     * @throws VolumeUnreachable When there are problems on the access to the remote volume (network,NFS,etc).
     * @throws NoWritableVolumesAvailable When there are no writable volumes available to store contents into.
     * @throws NoSuchCompressor When the COMPRESS_MODE given, doesn't correspond to any of the compressors defined in the config file.
	 */
	public synchronized Key store(Content content)
		throws VolumeUnreachable,NoWritableVolumesAvailable,NoSuchCompressor {
		return put(content,defaultCompressMode, defaultDuplicatesPolicy);
	}
	
    private Key put(Content content, int COMPRESS_MODE, int STORE_MODE) 
    	throws VolumeUnreachable,NoWritableVolumesAvailable,NoSuchCompressor {
        
		Compressor comp = getCompressor(COMPRESS_MODE);  
		
		if(comp == null) {
			throw new NoSuchCompressor(COMPRESS_MODE);
		}
						
		Key ret = null;
		
		/* the search for a duplicate only occours if not on the force new policy,
		   since this policy always results in a new content */
		if(STORE_MODE != FORCE_NEW_POLICY) {
		    /* find a duplicate. not-null if sucessful; in this case, the content was already stored. */
		    ret = findDuplicate(content,STORE_MODE,comp);
		}
    	
    	/* we only proceed if findDuplicate didn't store the content before (it didn't return a Key) */ 
    	if(ret == null) {
	    	try {
	    		/* ROUND-ROBIN POLICY NOT APPLIED, sig mod volumes.length instead */	       
	        	
	        	int index = sigModWritableVolLength(content);
	        		        
	        	ret = volumes[index].put(content,comp,STORE_MODE);
	    	}
	    	catch(VolumeUnreachable ex1) {
	    		throw ex1;
	    	}
	    	catch(Exception ex2) {
	    		ex2.printStackTrace();
	    	}
    	}
    	
        return ret;
    }

    /**
     * Stores a content in a specified volume.
     *
     * @param content Content to store.
     * @param volume Volume where to store the content.
     *
     * @return A key that makes possible the access to the stored content later.
     *
     * @throws VolumeNotWritable When the given volume is complete.
     * @throws VolumeUnreachable When there are problems on the access to the remote volume (network,NFS,etc).
     * @throws NoSuchCompressor When the COMPRESS_MODE given, doesn't correspond to any of the compressors defined in the config file.
     */
    public synchronized Key store(Content content, Volume volume)
    	throws VolumeNotWritable,VolumeUnreachable,NoSuchCompressor {
    		return put(content, volume, defaultCompressMode, defaultDuplicatesPolicy);
    }
    
    
	private Key put(Content content, Volume volume, int COMPRESS_MODE, int STORE_MODE)
		throws VolumeNotWritable,VolumeUnreachable,NoSuchCompressor {
        if(volume.isFull()) {
            throw new VolumeNotWritable(volume);
        }
        
        Compressor comp = null;
        comp = getCompressor(COMPRESS_MODE);
		if(comp == null) {
			throw new NoSuchCompressor(COMPRESS_MODE);
		}

		Key ret = null;
		try {
			/* exists() if positive, stores the content */
			Object o = volume.exists(content, STORE_MODE, comp);
			
			if(o instanceof Key)
				ret = (Key) o;
			else
				ret = volume.put(content, comp, STORE_MODE);
		}
		catch(VolumeUnreachable ex1) {
			throw ex1;
		}
		catch(Exception ex2) {
			ex2.printStackTrace();
		}
		
        return ret; 
    }
        
    
    /**
     * Retrieves a previously stored content.
     *
     * @param key Content's key.
     *
     * @return Content corresponding to the given key.
     *
     * @throws ContentNotFound When the content to retrieve wasn't found.
     * @throws NoSuchCompressor When there is no compressor available to decompress the stored data.
     * @throws DecompressionError When there was a compression error, possibly due to invalid compressed data.
     * @throws VolumeUnreachable When there are problems on the access to the remote volume (network,NFS,etc).
     * @throws InvalidKey When the given key isn't valid for this WebStore instance.
     */
    public synchronized Content retrieve(Key key)
    	throws ContentNotFound, VolumeUnreachable, NoSuchCompressor, DecompressionError, InvalidKey  {
    		
		CompressedContent cc = null;
		try {
			Volume v = matchVolume(key);
			cc = v.get(key);
		}
		catch(ContentNotFound ex1) {
			throw ex1;
		}
		catch(VolumeUnreachable ex2) {
			throw ex2;
		}
    
        Compressor comp = null;
        comp = matchCompressor(cc.getCompressionMode());
		if(comp == null) {
			throw new NoSuchCompressor("Compressor not found. [" + cc.getCompressionMode() + "]; key: " + key);
		}
        
	
        Content ret = null;
        
		try {
			ret = new Content(comp.inflate(cc.getCompressedContent())); 
		}
		catch(DecompressionError ex) {
			ex.printStackTrace();
		}
	
        return ret; 
    }

	/**
	 * Retrieves a previously stored content.
	 *
	 * @param externalFormatKey Content's key, in the external formal, that can be obtained through Key.toExternalFormat().
	 * 
	 * @return Content corresponding to the given key.
	 *
	 * @throws ContentNotFound When the content to retrieve wasn't found.
	 * @throws NoSuchCompressor When there is no compressor available to decompress the stored data.
	 * @throws DecompressionError When there was a compression error, possibly due to invalid compressed data.
	 * @throws VolumeUnreachable When there are problems on the access to the remote volume (network,NFS,etc).
	 * @throws InvalidKey When the given key isn't valid for this WebStore instance.
	 */
    public Content retrieve(String externalFormatKey)
		throws ContentNotFound, VolumeUnreachable, NoSuchCompressor, DecompressionError, InvalidKey {
    	return retrieve(Key.toKey(externalFormatKey));
    }
    
    /**
     * Deletes a previously stored content.
     *
     * @param key Content's key.
     *
     * @throws ContentNotFound When the content to delete wasn't found.
     * @throws VolumeUnreachable When there are problems on the access to the remote volume (network,NFS,etc).
     * @throws InvalidKey When the given key isn't valid for this WebStore instance.
     */
    public synchronized void delete(Key key) throws ContentNotFound, VolumeUnreachable, InvalidKey {
    	try {
			Volume v = matchVolume(key);
			v.delete(key);
    	}
    	catch(ContentNotFound ex1) {
    		throw ex1;
    	}
    	catch(VolumeUnreachable ex2) {
			throw ex2;
		}
    }

	/**
	  * Deletes a previously stored content.
	  *
	  * @param externalFormatKey Content's key, in the external formal, that can be obtained through Key.toExternalFormat().
	  *
	  * @throws ContentNotFound When the content to delete wasn't found.
	  * @throws VolumeUnreachable When there are problems on the access to the remote volume (network,NFS,etc).
	  * @throws InvalidKey When the given key isn't valid for this WebStore instance.
	  */
	public void delete(String externalFormatKey)
		throws ContentNotFound, VolumeUnreachable, InvalidKey {
		delete(Key.toKey(externalFormatKey));
	}
		
    /**
     * Obtains the volumes that compose the WebStore.
     *
     * @return An array of Volume, containing all of them.
     */
    public synchronized Volume[] getVolumes() {
        return volumes;
    }

    /**
     * Obtains the volumes of the WebStore acording to a given type.
     *
     * @param TYPE Type of Volume (WebStore.FULL or WebStore.WRITABLE).
     *
     * @return An array of Volume.
     */
    public Volume[] getVolumes(int TYPE) {
        Vector vols = new Vector();
        for(int i = 0; i < volumes.length; i++) {
			if(TYPE == FULL) {
				if(volumes[i].isFull())
					vols.addElement(volumes[i]);
			}
			else 
				if(TYPE == WRITABLE) {
					if(!volumes[i].isFull())
						vols.addElement(volumes[i]);
				}
				else
					System.err.println("Incorrect TYPE.");
        }
        	
        Volume[] ret = new Volume[vols.size()];
        for(int i = 0; i < ret.length; i++)
        	ret[i] = (Volume) vols.elementAt(i);
        
        return ret;
    }

    /**
     * Returns the name of the WebStore instance.
     *
     * @return A string representing its name.
     */
    public String getName() {
        return name;
    }

	/**
	 * Obtains a compressor given its code. Codes are defined in Compressor.java.
	 * 
	 * @param compress_mode Code corresponding to a compressor.
	 * 
	 * @return The compressor correspondent to the given code.
	 *  
	 * @throws NoSuchCompressor When there wasn't any compressor available with the given code. 
	 */
    private Compressor getCompressor(int compress_mode) throws NoSuchCompressor {
        int i = 0;
        for(; i < compressors_code.length; i++)
            if(compressors_code[i] == compress_mode)
                return compressors[i];

        throw new NoSuchCompressor(compress_mode);
    }
    
    /**
     * Given a string with a compressor name, tries to match one available.
     * 
	 * @param compress_name Compressor's name.
	 *  
	 * @return The compressor corresponding to the given name.
	 * 	
	 * @throws NoSuchCompressor When there wasn't any matching compressor available. 
	 */
	private Compressor matchCompressor(String compress_name) throws NoSuchCompressor {
        for(int i = 0; i < compressors.length; i++)
            if(compressors[i].toString().equals(compress_name))
                return compressors[i];
        throw new NoSuchCompressor(compress_name);
    }
        
    private Volume matchVolume(Key key) throws InvalidKey {
    	Volume ret = null;
    	String id = key.getVolumeID();
    	for(int i = 0; ret == null && i < volumes.length; i++)
    		if(volumes[i].vol_id.equals(id))
    			ret = volumes[i];
    	
    	if(ret == null)
    		throw new InvalidKey(key);
    		
    	return ret;
    }
    
    
    /**
     * Finds a content's duplicate in the available volumes.
     */
     private Key findDuplicate(Content content, int POLICY, Compressor compressor) 
     throws VolumeUnreachable, NoWritableVolumesAvailable {
     	int hint = sigModWritableVolLength(content);
     	Key ret = volumes[hint].exists(content,POLICY,compressor);
     	
     	/* if it wasn't found with the hint, the volumes are sweeped. */
     	if(ret == null) {
     	    /* it only searches on writable volumes (!isFull()) */
     	    for(int i = 0; ret == null && i < volumes.length; i++)
	 		    if(i != hint && !volumes[i].isFull())
	 		        ret = volumes[i].exists(content,POLICY,compressor);
     	}
	 		
		return ret;
     }
     
     /**
      * calculates the content's hash mod number of writable volumes;
      * returns an index of a writable volume
      */ 
     private int sigModWritableVolLength(Content content)
     throws NoWritableVolumesAvailable {
         long len = (long) writable_volumes_length;
         int i = Math.abs((int) (content.getSignature() % len));
         int index = 0, j = -1;
         boolean ok = false;
         while(index < volumes.length && !ok) {
             if(!volumes[index].isFull())
                 j++;
             
             if(j == i)
                 ok = true;
             else
                 index++;
         }
         
         if(!ok)
             throw new NoWritableVolumesAvailable();
         
         return index;
     }
     
     
}
