/*
 * MaintenanceRobot.java
 *
 * Created on December 29, 2002, 6:21 PM
 *
 * Copyright (C) 2003 Thought River North and Thought River South, All Rights 
 * Reserved. 
 *
 * Unless explicitly acquired and licensed from Licensor, the contents of this 
 * file are subject to the Reciprocal Public License ("RPL") Version 1.1, or 
 * subsequent versions as allowed by the RPL, and You may not copy or use this 
 * file in either source code or executable form, except in compliance with the 
 * terms and conditions of the RPL. 
 *
 * You may obtain a copy of the RPL (the "License") from the Open Source 
 * Initiative at http://www.opensource.org.
 *
 * All software distributed under the Licenses is provided strictly on an "AS 
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, AND 
 * THOUGHT RIVER NORTH AND THOUGHT RIVER SOUTH HEREBY DISCLAIM ALL SUCH 
 * WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See 
 * the License for specific language governing rights and limitations under the 
 * License.
 */

package pt.tumba.util.maintenance;

import java.util.*;
import java.io.*;


/**
 * This class is used to schedule various inspection and repair tasks on any
 * object that implements the <CODE>Repairable</CODE> interface.  Inspections
 * and repairs take two basic forms: "quick" and "full".  Quick inspections
 * and repairs can be done in a negligible amount of time, meaning they can
 * safely be done often.  Full inspections and repairs are more involved, and
 * therefore should be done less frequently.
 * <P>
 * Every instance of <CODE>MaintenanceRobot</CODE> maintains its own scheduling
 * system and list of <CODE>Repairable</CODE> objects, so if very complex
 * scheduling management is desired, multiple robots can be used.
 * <P>
 * Finally, a <CODE>MaintenanceRobot</CODE> can (and should) be configured with
 * an <CODE>IrreparableProblemStrategy</CODE> object capable of responding to
 * <CODE>IllegalStateException</CODE>s that are produced during the process of
 * inspecting or repairing an object.  This typically represents a total system
 * failure.
 *
 * @author Brandon Franklin
 * @version $Date: 2003/11/21 15:42:47 $
 */
public class MaintenanceRobot {
	
	/** The <CODE>Repairable</CODE> objects being maintained by this instance */
	protected List repairables = null;
	
	/** The <CODE>Timer</CODE> used to schedule inspections and repairs */
	protected Timer timer = null;
	
	/** The stream to which output messages should be sent */
	protected PrintStream out = null;
	
	/** The strategy used when repairs are otherwise impossible */
	protected IrreparableProblemStrategy irreparableProblemStrategy = null;
	
	
	/**
	 * Creates a new instance of <CODE>MaintenanceRobot</CODE>, set to run in
	 * silent mode.
	 */
	public MaintenanceRobot() {
		this( null );
	}

	/**
	 * Creates a new instance of <CODE>MaintenanceRobot</CODE>, set to send
	 * output to the provided stream.  If the stream is null, the instance will
	 * run in silent mode.
	 *
	 * @param out the stream to which output should be sent
	 */
	public MaintenanceRobot(PrintStream out) {
		this.out = out;
		repairables = Collections.synchronizedList( new LinkedList() );
	}
	
	/**
	 * Tells the <CODE>MaintenanceRobot</CODE> to begin performing inspection
	 * and repair cycles, with the specified number of milliseconds between
	 * the end of one execution and the beginning of the next.  The delay
	 * settings can (and should) be different for quick inspections and full
	 * inspections, with quick inspections occurring much more frequently.
	 *
	 * @param fullDelay the number of milliseconds between the end of one 
	 * execution of a full inspection and the beginning of the next
	 * @param quickDelay the number of milliseconds between the end of one 
	 * execution of a quick inspection and the beginning of the next
	 */
	public synchronized void start(long fullDelay, long quickDelay) {

		if( timer == null ) {
			
			timer = new Timer();

			// Schedule the first quick inspection
			TimerTask quickTask = new MaintenanceRobot.Task( false, quickDelay );
			timer.schedule( quickTask, quickDelay );

			// Schedule the first full inspection
			TimerTask fullTask = new MaintenanceRobot.Task( true, fullDelay );
			timer.schedule( fullTask, fullDelay );

			if( out != null ) {
				out.println(this+": started with "+quickDelay+" ms / "+fullDelay+" ms delay settings");
			}
			
		} else {
			if( out != null ) {
				out.println(this+": start requested, but already running");
			}
		}
	}
	
	/**
	 * Tells the <CODE>MaintenanceRobot</CODE> to stop performing inspection
	 * and repair cycles.
	 */
	public synchronized void stop() {
		
		if( timer != null ) {
			
			// Cancel all the tasks in the timer
			timer.cancel();

			if( out != null ) {
				out.println(this+": stopped");
			}

			timer = null;
			
		} else {
			if( out != null ) {
				out.println(this+": stop requested, but already stopped");
			}
		}
			
	}
	
	/**
	 * Adds a <CODE>Repairable</CODE> to the list of objects being maintained
	 * by this <CODE>MaintenanceRobot</CODE>.
	 *
	 * @param repairable a <CODE>Repairable</CODE> to be added to the list of
	 * objects being maintained
	 */
	public void maintain(Repairable repairable) {
		repairables.add( repairable );		
	}

	/**
	 * Removes a <CODE>Repairable</CODE> from the list of objects being 
	 * maintained by this <CODE>MaintenanceRobot</CODE>.
	 *
	 * @param repairable a <CODE>Repairable</CODE> to be removed from the list 
	 * of objects being maintained
	 */
	public void abandon(Repairable repairable) {
		repairables.remove( repairable );
	}
	
	/**
	 * Specifies the <CODE>IrreparableProblemStrategy</CODE> that will be used
	 * in the event that an <CODE>IllegalStateException</CODE> is encountered
	 * during an inspection and repair cycle. Supplying a null value is allowed,
	 * and will result in the use of no strategy in the event of a disaster. It
	 * is not, therefore, recommended in most cases.
	 *
	 * @param ips the <CODE>IrreparableProblemStrategy</CODE> that will be used
	 * when repairs are otherwise impossible
	 */
	public synchronized void setIrreparableProblemStrategy(IrreparableProblemStrategy ips) {
		irreparableProblemStrategy = ips;
	}

	/**
	 * Returns the <CODE>IrreparableProblemStrategy</CODE> that will be used
	 * in the event that an <CODE>IllegalStateException</CODE> is encountered
	 * during an inspection and repair cycle. This can be null, and indicates that
	 * no strategy should be used in the event of a disaster.
	 *
	 * @return the <CODE>IrreparableProblemStrategy</CODE> that will be used
	 * when repairs are otherwise impossible
	 */
	public synchronized IrreparableProblemStrategy getIrreparableProblemStrategy() {
		return irreparableProblemStrategy;
	}
	
	/**
	 * Instructs this <CODE>MaintenanceRobot</CODE> to immediately make inspections
	 * and repairs of the specified type on all <CODE>Repairable</CODE> objects it is
	 * maintaining.
	 *
	 * @param fullRepairs true if full inspections and repairs should be made, 
	 * false if quick inspections and repairs should be made
	 *
	 * @return a <CODE>List</CODE> of the repairs that were made
	 */
	public List makeRepairs(boolean fullRepairs) {
		
		List repairList = new LinkedList();

		// Lock, and make a copy of the Repairables
		List repairCandidates = null;
		synchronized( repairables ) {
			repairCandidates = new LinkedList( repairables );
		}

		// Iterate over each Repairable, making repairs in sequence
		for( Iterator iter = repairCandidates.iterator(); iter.hasNext(); ) {
			Repairable repairable = (Repairable)iter.next();
			List repairs = null;
			try {
				if( fullRepairs) {
					repairs = repairable.makeFullRepairs();
				} else {
					repairs = repairable.makeQuickRepairs();
				}
			} catch (IllegalStateException ise) {

				// If this happens, hopefully we have a strategy in place
				IrreparableProblemStrategy ips = getIrreparableProblemStrategy();
				if( ips != null ) {
					ips.activate( ise );
				}
			}

			// Add the list of repairs done to the "master list"
			repairList.addAll( repairs );
		}

		// Possibly display a list of the repairs that were done
		if( out != null ) {
			if( fullRepairs ) {
				out.println(this+": executed a full inspection and repair cycle");
			} else {
				out.println(this+": executed a quick inspection and repair cycle");
			}

			if( !repairList.isEmpty() ) {
				out.println(this+": performed the following repairs...");

				for( Iterator iter = repairList.iterator(); iter.hasNext(); ) {
					out.println(" -- "+ iter.next() );
				}
			}
		}
		
		return repairList;
	}
	
	
	/**
	 * This class represents a single scheduled inspection and repair cycle.
	 * Each instance of this class is used to generate and schedule the next
	 * instance with the appropriate delay. A <CODE>Task</CODE> can either be
	 * for quick inspections and repairs, or for full inspections and repairs,
	 * and will call the appropriate methods on the <CODE>Repairable</CODE>s
	 * when it is run.
	 */
	protected class Task extends TimerTask {
		
		/** Whether or not this <CODE>Task</CODE> performs full inspections */
		private boolean fullRepairs = false;
		
		/** The number of milliseconds between full inspection and repair cycles */
		private long delay = 0;
		
				
		/**
		 * Creates a new instance of <CODE>Task</CODE> and sets whether or
		 * not it does full inspections and repairs.
		 *
		 * @param fullRepairs whether or not this <CODE>Task</CODE> should
		 * perform full inspections and repairs
		 * @param delay the number of milliseconds between the end of one 
		 * execution of this task's inspection and the beginning of the next
		 */
		public Task(boolean fullRepairs, long delay) {
			this.fullRepairs = fullRepairs;
			this.delay = delay;
		}
		
		/** 
		 * This method is called when the scheduled task is executed.
		 */
		public void run() {
			
			makeRepairs( fullRepairs );
			
			// Reschedule the task for the next execution
			synchronized( MaintenanceRobot.this ) {
				if( timer != null ) {
					timer.schedule( this, delay );
				}
			}
		}
		
	}
	
}
